gcc cond.c -omain -lpthread
gcc cond2.c -omain2 -lpthread
