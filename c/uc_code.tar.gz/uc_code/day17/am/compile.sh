#gcc demo1.c -omain -lpthread
gcc sem.c -omain -lpthread
gcc cond.c -omain -lpthread
