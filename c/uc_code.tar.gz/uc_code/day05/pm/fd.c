#include <stdio.h>
#include <unistd.h>

main()
{
	printf("%d\n",getpid());
	while(1);
}
