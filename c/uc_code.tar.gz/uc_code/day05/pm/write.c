#include <unistd.h>


main()
{

	write(1,"Hello\n",6);

}
