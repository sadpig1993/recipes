#gcc printf.c -oprintfmain
#gcc fd.c -ofdmain
#gcc write.c -owritemain
#gcc read.c -oreadmain
gcc open_write.c -oopen_writemain
#gcc open_read.c -oopen_readmain
#gcc isatty.c -oisattymain
#gcc readmem.c -oreadmemmain
