#gcc arge.c -oargemain
#gcc errno.c -oerrno
gcc printf.c -oprintfmain
