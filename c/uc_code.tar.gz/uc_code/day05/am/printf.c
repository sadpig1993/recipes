#include <stdio.h>

main()
{
	printf("%*d\n",20,30);
}
