#gcc demo1.c -omain1 -lpthread -lcurses
#gcc demo2.c -omain2-lpthread -lcurses
#gcc demo3.c -omain3 -lpthread -lcurses
#gcc demo4.c -omain4 -lpthread -lcurses
#gcc th_problem.c -omain_prob -lpthread 
#gcc pthread_exit.c -omain_cancel -lpthread 
#gcc pthread_exit2.c -omain_cancel2 -lpthread 
#gcc pthread_exit3.c -omain_exit -lpthread 
#gcc pthread_exit4.c -omain_exit2 -lpthread 
#gcc pthread_signal.c -omain_signal -lpthread 
gcc pthread_sigwait.c -omain_signal2 -lpthread 
gcc demo5.c -omain5 -lpthread -lcurses
gcc demo6.c -omain6 -lpthread -lcurses
