gcc pthread_create.c -omain -lpthread
