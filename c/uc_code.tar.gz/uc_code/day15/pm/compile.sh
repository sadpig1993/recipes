gcc httpserver.c -oserver
gcc httpclient.c -oclient
