#gcc raw.c -omain
gcc broadcast_send.c -osend
gcc broadcast_recv.c -orecv
