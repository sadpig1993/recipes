#gcc killA.c -oA
#gcc killB.c -oB
#gcc demo2.c -omain -lcurses
gcc sigprocmask.c -omain 
