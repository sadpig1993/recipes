gcc 01simplecurse.c -omain -lcurses
#gcc addch.c -omain -lcurses
#gcc demo1.c -omain -lcurses
#gcc demo2.c -omain -lcurses
#gcc printw.c -omain -lcurses
#gcc demo3.c -omain -lcurses
#gcc demo4.c -omain -lcurses
