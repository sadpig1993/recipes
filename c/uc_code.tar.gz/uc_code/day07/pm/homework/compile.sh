gcc work1.c -omain -lcurses
