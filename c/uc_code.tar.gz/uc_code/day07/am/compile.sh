#gcc dup.c -omain
#gcc fcntl.c -omain
#gcc dir.c -omain
gcc scandir.c -omain
