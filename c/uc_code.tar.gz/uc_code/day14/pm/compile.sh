#gcc poll.c -omain
#gcc ioctl.c -omain
gcc raw.c -omain
gcc chatClient.c -oClient
gcc chatServer.c -oServer
