#gcc asyncio.c -omain
#gcc select.c -omain
gcc chatClient.c -oClient
gcc chatServer_select.c -oServer
