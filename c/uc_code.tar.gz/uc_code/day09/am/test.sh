#!/bin/bash
#for popen.c  read
#echo "Hello World"


#for popen.c write
read a
echo $a
