#gcc exec.c -omain
gcc popen.c -omain
#gcc fork.c -omain
#gcc fork2.c -omain
#gcc fork3.c -omain3
#gcc fork4.c -omain4
#gcc fork5.c -omain5
