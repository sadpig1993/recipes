#gcc mapA.c -oA
#gcc mapB.c -oB
#gcc fdA.c -oA
#gcc fdB.c -oB
#gcc forkfd.c -oforkfdmain
#gcc parentchild.c -omain
gcc demo1.c -omain -lcurses
#gcc demo2.c -omain -lcurses
