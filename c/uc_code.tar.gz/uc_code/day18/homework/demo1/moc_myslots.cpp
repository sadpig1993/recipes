/****************************************************************************
** Meta object code from reading C++ file 'myslots.h'
**
** Created: Tue Dec 18 11:53:31 2012
**      by: The Qt Meta Object Compiler version 61 (Qt 4.5.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "myslots.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'myslots.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 61
#error "This file was generated using the moc from 4.5.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_MySlots[] = {

 // content:
       2,       // revision
       0,       // classname
       0,    0, // classinfo
       2,   12, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors

 // slots: signature, parameters, type, tag, flags
       9,    8,    8,    8, 0x0a,
      21,    8,    8,    8, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_MySlots[] = {
    "MySlots\0\0handle_ok()\0handle_cancel()\0"
};

const QMetaObject MySlots::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_MySlots,
      qt_meta_data_MySlots, 0 }
};

const QMetaObject *MySlots::metaObject() const
{
    return &staticMetaObject;
}

void *MySlots::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_MySlots))
        return static_cast<void*>(const_cast< MySlots*>(this));
    return QObject::qt_metacast(_clname);
}

int MySlots::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: handle_ok(); break;
        case 1: handle_cancel(); break;
        default: ;
        }
        _id -= 2;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
