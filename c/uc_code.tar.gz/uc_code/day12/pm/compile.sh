#gcc socketA.c -oA
#gcc socketB.c -oB
#gcc csA.c -oA
#gcc csB.c -oB
#gcc ipaddr.c -omain
#gcc hosts.c -omain
gcc protocol.c -omain
