gcc socketA.c -oA
gcc socketB.c -oB
