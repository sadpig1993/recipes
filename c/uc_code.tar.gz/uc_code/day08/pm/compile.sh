#gcc  sigwinch.c -omain -lcurses
#gcc  alert.c -omain 
#gcc  setitimer.c -omain 
#gcc  derwin.c -omain -lcurses
gcc  system.c -omain 
gcc  a.c -otesta
