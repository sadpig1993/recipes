#!/bin/sh
echo Hello
exit 1
