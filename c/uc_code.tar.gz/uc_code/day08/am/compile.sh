#gcc  main.c -omain -lcurses
#gcc  derwin.c -omain -lcurses
gcc  sigwinch.c -omain -lcurses
