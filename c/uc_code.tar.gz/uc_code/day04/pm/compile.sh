#gcc vmema.c -ovmema
#gcc vmemb.c -ovmemb
#g++ newmalloc.cpp -onewmalloc
#g++ replacealloc.cpp -oreplacealloc
#gcc brk.c -obrkmain
#gcc Demo1.c -oDemo1main
#g++ Demo2.cpp -oDemo2
gcc map.c -omap
