gcc funcpointer.c -omain
gcc memseg.c -omemseg
gcc memaddr.c -omemaddr
