#gcc tcpServer.c -otcpServer
#gcc tcpClient.c -otcpClient
#gcc udpA.c -oudpServer
#gcc udpB.c -oudpClient
gcc udpServerint.c -oudpServerint
gcc udpClientint.c -oudpClientint
