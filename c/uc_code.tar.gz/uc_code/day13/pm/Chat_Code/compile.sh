gcc chatServer.c -ochatServer
gcc chatClient.c -ochatClient
