gcc demoFileServer.c -oFileServer
gcc demoFileClient.c -oFileClient
