gcc main.c -ldl -omain
