gcc -shared -fpic ku.c -olibku.so
