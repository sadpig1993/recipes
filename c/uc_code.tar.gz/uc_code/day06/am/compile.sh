#gcc text.c -omain
#gcc lseek.c -omain
#gcc lseek2.c -omain
#gcc lseek3.c -omain
#gcc fstat.c -omain
#gcc ftruncate.c -omain
gcc ftruncate2.c -omain
