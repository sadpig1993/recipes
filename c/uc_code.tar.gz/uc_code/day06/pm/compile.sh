#gcc map_write.c -omain
#gcc map_write2.c -omain
#gcc map_read2.c -omain
gcc ioproblem.c -omain
