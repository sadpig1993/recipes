var box= {
		box0000:[{value:"",text:"请选择"},{value:"01",text:"身份证"},{value:"02",text:"军官证"},{value:"03",text:"护照"},{value:"04",text:"港澳居民来往内地通行证"},{value:"05",text:"台湾同胞来往内地通行证"},{value:"06",text:"警官证"},{value:"07",text:"士兵证"},{value:"08",text:"户口簿"},{value:"09",text:"临时身份证"},{value:"10",text:"外国人居留证"},{value:"99",text:"其他证件"}],
		box0001:[{value:"",text:"请选择"},{value:"156",text:"元"},{value:"344",text:"港币"},{value:"392",text:"日元"},{value:"840",text:"美元"},{value:"901",text:"新台币"},{value:"978",text:"欧元"}],
		box0002:[{value:"00000001",text:"长沙卡友"},{value:"00000002",text:"兴业银行"},{value:"00000003",text:"湖南农信"},{value:"00000004",text:"光大银行"}],
		box0003:[{value:"",text:"请选择"},{value:"0",text:"自有"},{value:"1",text:"租用"}],
		box0004:[{value:"",text:"请选择"},{value:"0",text:"普通POS"},{value:"1",text:"分体式POS"},{value:"2",text:"移动POS"},{value:"3",text:"网络POS"},{value:"4",text:"电话POS"}],
		box0005:[{value:"",text:"请选择"},{value:"0",text:"按月"},{value:"1",text:"按季"}],
		box0006:[{value:"",text:"请选择"},{value:"0",text:"热敏纸"},{value:"1",text:"针打纸"}],
		box0007:[{value:"0",text:"传统POS商户"},{value:"1",text:"服务提供机构"},{value:"2",text:"接入渠道机构"},{value:"3",text:"CUPSECUPE商户"},{value:"4",text:"虚拟商户"},{value:"5",text:"行业商户"},{value:"6",text:"服务提供机构+接入渠道机构"},{value:"7",text:"多渠道直联终端商户"}],
		box0008:[{value:"156",text:"中国"}],
		box0009:[{value:"",text:"请选择"},{value:"00",text:"综合零售"},{value:"01",text:"专门零售"},{value:"02",text:"批发类"},{value:"03",text:"住宿餐饮"},{value:"04",text:"休闲娱乐"},{value:"05",text:"房地产业"},{value:"06",text:"金融业"},{value:"07",text:"政府服务"},{value:"08",text:"教育"},{value:"09",text:"卫生"},{value:"10",text:"公共事业"},{value:"11",text:"居民服务"},{value:"12",text:"商业服务"},{value:"13",text:"交通物流"},{value:"14",text:"直销类商户"},{value:"15",text:"租赁服务"},{value:"16",text:"维修服务"},{value:"17",text:"其它"}],
		box0010:[{value:"",text:"请选择"},{value:"00",text:"真实公益类"},{value:"01",text:"入网优惠期套用"},{value:"02",text:"公共事业类商户"},{value:"03",text:"批发市场类商户"},{value:"04",text:"资金归集类商户"},{value:"05",text:"历史遗留类套用"}],
		box0011:[{value:"1",text:"启用"},{value:"2",text:"冻结"}],
		box0012:[{value:"",text:"请选择"},{value:"00",text:"私自套用"},{value:"01",text:"经价格小组通过"},{value:"02",text:"当地协商"},{value:"03",text:"人民银行/人监会发文"},{value:"04",text:"同业公会发文"},{value:"05",text:"其他组织发文"},{value:"06",text:"其他"}],
		box0013:[{value:"",text:""},{value:"A1",text:"个人结算账户商户不允许受理信用卡交易"},{value:"A0",text:"无交易控制（用于用户T+0）"}],
		box0015:[{value:"",text:"请选择"},{value:"P",text:"直联POS"},{value:"S",text:"直联商户"}],
		box0016:[{value:"",text:"请选择"},{value:"010",text:"国有企业"},{value:"020",text:"集体企业"},{value:"030",text:"股份合作企业"},{value:"041",text:"国有联营企业"},{value:"042",text:"集体联营企业"},{value:"043",text:"国有与集体联营企业"},{value:"044",text:"其他联营企业"},{value:"051",text:"国有独资企业"},{value:"052",text:"其他有限责任公司"},{value:"060",text:"股份有限公司"},{value:"071",text:"私营独资企业"},{value:"072",text:"私营合伙企业"},{value:"073",text:"私营有限责任公司"},{value:"074",text:"私营股份有限公司"},{value:"080",text:"其他企业"},{value:"110",text:"合资经营企业"},{value:"120",text:"合作经营企业"},{value:"130",text:"独资经营企业"},{value:"140",text:"投资股份有限公司"},{value:"210",text:"中外合资经营企业"},{value:"220",text:"中外合作经营企业"},{value:"230",text:"外资企业"},{value:"240",text:"外商投资股份有限公司"},{value:"310",text:"政府机构"},{value:"320",text:"事业单位"}],
		box0017:[{value:"",text:"请选择"},{value:"01",text:"身份证"},{value:"02",text:"军官证"},{value:"03",text:"护照"},{value:"04",text:"港澳居民来往内地通行证（回乡证）"},{value:"05",text:"台湾同胞来往内地通行证（台胞证）"},{value:"06",text:"警官证"},{value:"07",text:"士兵证"},{value:"08",text:"户口簿"},{value:"09",text:"临时身份证"},{value:"10",text:"外国人居留证"},{value:"99",text:"其他证件"}],
		box0018:[{value:"",text:"请选择"},{value:"156",text:"元"}],
		box0019:[{value:"",text:"请选择"},{value:"1",text:"银联商务"},{value:"2",text:"好易联"},{value:"3",text:"好易联（番禹）"},{value:"4",text:"汉鑫"}],
		box0020:[{value:"",text:"请选择"},{value:"0",text:"未开通"},{value:"1",text:"已开通"},{value:"2",text:"已关闭"}],
		box0021:[{value:"",text:"请选择"},{value:"1",text:"收单行入账"},{value:"2",text:"结算行入账"},{value:"3",text:"银联小额入账"}],
		box0022:[{value:"",text:"请选择"},{value:"1",text:"清算到本店"},{value:"2",text:"清算到其他店"}],
		box0023:[{value:"",text:"请选择"},{value:"0",text:"日"},{value:"1",text:"月"},{value:"2",text:"季"},{value:"3",text:"半年"},{value:"4",text:"年"}],
		box0024:[{value:"",text:"请选择"},{value:"0",text:"部分回补"},{value:"1",text:"全部回补"},{value:"2",text:"不回补"}],
		box0025:[{value:"",text:"请选择"},{value:"0",text:"全部清本金"},{value:"1",text:"部分不清本金"}],
	  box0026:[{value:"00",text:"无特殊计费类型"},{value:"01",text:"周期计费"},{value:"02",text:"微额打包"},{value:"03",text:"固定比例"},{value:"04",text:"县乡优惠"}],
		box0027:[{value:"0",text:"月结且按照MCC计费"},{value:"1",text:"月结且不按照MCC计费"}],
		box0028:[{value:"",text:"请选择"},{value:"00",text:"直联"},{value:"01",text:"托管"}],
		box0029:[{value:"",text:"请选择"},{value:"01",text:"代提实时请求"},{value:"02",text:"代理实时应答"},{value:"03",text:"电子产品"},{value:"04",text:"既代提又代理"},{value:"05",text:"受托独立授权"}],
		box0030:[{value:"",text:"请选择"},{value:"0",text:"固定滞纳金"},{value:"1",text:"统一利率"},{value:"2",text:"按用户类型计算"}],
		box0031:[{value:"",text:"请选择"},{value:"0",text:"居民用户"},{value:"1",text:"非居民用户"},{value:"2",text:"其他"}],
		box0032:[{value:"",text:"请选择"},{value:"03",text:"随机生成"},{value:"04",text:"支付号码后六位"}],
		box0033:[{value:"",text:"请选择"},{value:"01",text:"国税"},{value:"02",text:"地税"},{value:"RZ",text:"日终对账用"}],
		box0034:[{value:"",text:"请选择"},{value:"0",text:"不加密"},{value:"1",text:"des"},{value:"6",text:"3des"}],
		box0035:[{value:"00",text:"POS"},{value:"01",text:"MIS"},{value:"02",text:"ATM"},{value:"03",text:"CDM"},{value:"04",text:"多媒体"},{value:"05",text:"电话"},{value:"06",text:"手机"},{value:"07",text:"机顶盒"},{value:"08",text:"网支"},{value:"09",text:"终端转账"},{value:"10",text:"I型电话支付终端（家用型）"},{value:"11",text:"II型电话支付终端（商用型）"},{value:"12",text:"虚拟终端"},{value:"13",text:"自定义1"},{value:"14",text:"自定义2"}],
		box0036:[{value:"",text:"请选择"},{value:"1",text:"DES"},{value:"3",text:"3DES"}],
		box0037:[{value:"",text:"请选择"},{value:"0",text:"多机一密"}, {value:"1",text:"一机一密"},{value:"2",text:"一商一密"}, {value:"3",text:"一区一密"}, {value:"4",text:"自定义"}],
		box0038:[{value:"",text:"请选择"},{value:"01",text:"单倍长"},{value:"02",text:"双倍长"},{value:"03",text:"三倍长"}],
		box0039:[{value:"",text:"请选择"},{value:"01",text:"ANSI19.9"},{value:"02",text:"ANSI9.19"},{value:"03",text:"XOR"}],
		box0040:[{value:"",text:"请选择"},{value:"00",text:"手工传输"},{value:"01",text:"FTP文件"},{value:"02",text:"自定义"}],
    box0041:[{value:"",text:"请选择"},{value:"01",text:"单倍长"},{value:"02",text:"双倍长"},{value:"03",text:"三倍长"}],
    box0042:[{value:"",text:"请选择"},{value:"01",text:"单倍长"},{value:"02",text:"双倍长"},{value:"03",text:"三倍长"}],
		box0043:[{value:"",text:"请选择"},{value:"01",text:"单倍长"},{value:"02",text:"双倍长"},{value:"03",text:"三倍长"}],
		box0044:[{value:"",text:"请选择"},{value:"0",text:"固定扣率"},{value:"1",text:"百分比起封顶"},{value:"3",text:"百分比起封顶超过再封顶"},{value:"4",text:"按百分比"}],
		box0045:[{value:"",text:"请选择"},{value:"01",text:"交通银行"},{value:"02",text:"中信银行"},{value:"03",text:"光大银行"},{value:"04",text:"兴业银行"},{value:"05",text:"湖南农信"}],
		box0046:[{value:"",text:"请选择"},{value:"01",text:"基本金融菜单"},{value:"02",text:"兴业通菜单"},{value:"03",text:"电力缴费菜单"},{value:"04",text:"电信积分菜单"},{value:"05",text:"支票圈存菜单"},{value:"06",text:"长沙卡友消费菜单"},{value:"07",text:"中信财富通菜单"},{value:"08",text:"邮储信付通菜单"},{value:"09",text:"光大通菜单"},{value:"10",text:"福祥卡菜单"},{value:"11",text:"行内转帐优先"},{value:"12",text:"消费交行家居通宝菜单"},{value:"13",text:"小额取现菜单"},{value:"14",text:"长沙银行消费菜单"},{value:"15",text:"储值卡菜单"},{value:"16",text:"新农保菜单"},{value:"17",text:"业主收款交行家居通宝菜单"},{value:"18",text:"招行招财通菜单"}],
		box0047:[{value:"",text:"请选择"},{value:"01",text:"基本金融菜单"},{value:"02",text:"行内转帐优先"},{value:"03",text:"跨行汇款"},{value:"04",text:"支票圈存"},{value:"05",text:"消费交行家居通宝菜单"},{value:"06",text:"兴业通菜单"},{value:"07",text:"游戏一卡通销售"},{value:"08",text:"税银通菜单"},{value:"09",text:"中信财富通菜单"},{value:"10",text:"电力缴费菜单"},{value:"11",text:"新农合菜单"},{value:"12",text:"电信积分菜单"},{value:"13",text:"福祥卡菜单"},{value:"14",text:"兴业通2菜单"},{value:"15",text:"邮储信付通菜单"},{value:"16",text:"小额取现菜单"},{value:"17",text:"长沙银行消费菜单"},{value:"18",text:"新农保菜单"},{value:"19",text:"业主收款交行家居通宝菜单"},{value:"20",text:"招行招财通菜单"},{value:"21",text:"雨花农信菜单"}],
    box0048:[{value:"",text:"请选择"},{value:"CS022",text:"按比例1%"},{value:"CS023",text:"按比例0%"},{value:"CS024",text:"按比例2.5%"},{value:"CS025",text:"按比例2%"},{value:"CS026",text:"按比例1.5%"},{value:"CS027",text:"按比例1.9%"},{value:"CS028",text:"按比例3%"},{value:"CS029",text:"按比例1.8%"},{value:"CS030",text:"按比例0.5%"},{value:"CS031",text:"按比例0.8%"},{value:"CS032",text:"按比例0.3%"},{value:"CS033",text:"按比例0.01%"},{value:"CS036",text:"按比例1%",text:"55元"},{value:"CS039",text:"按比例1%",text:"50元"},{value:"CS040",text:"按比例1%",text:"22元，5万以上55元"},{value:"CS041",text:"按比例0.05%"},{value:"CS042",text:"按比例0.4%"},{value:"CS043",text:"按比例0.45%"},{value:"CS044",text:"按比例0.6%"},{value:"CS045",text:"按比例0.09%"},{value:"CS046",text:"按比例1%",text:"22元"},{value:"CS047",text:"按比例0.2%",text:"22元"},{value:"CS049",text:"按比例0.95%"},{value:"CS052",text:"按比例0.08%"},{value:"CS053",text:"按比例0.1%"},{value:"CS056",text:"按比例1%",text:"40元"},{value:"CS058",text:"固定金额0.5元"},{value:"CS060",text:"按比例0.2%"},{value:"CS061",text:"按比例0.06%"},{value:"CS062",text:" nothing"},{value:"CS064",text:"按比例1.2%"},{value:"CS066",text:"按比例1%",text:"20元"},{value:"CS067",text:"按比例1%",text:"35元"},{value:"CS068",text:"按比例1%",text:"56元"},{value:"CS070",text:"按比例1%",text:"30元"},{value:"CS072",text:"按比例0.7%"},{value:"CS073",text:"固定金额0.3元"},{value:"CS074",text:"按比例0.07%"},{value:"CS077",text:"不计费"},{value:"CS078",text:"按比例0.495%"},{value:"CS079",text:"按比例0.9%"},{value:"CS080",text:"按比例0.85%"},{value:"CS081",text:"按比例1.7%"},{value:"CS082",text:"按比例5%"},{value:"CS083",text:"按比例0.2%",text:"20元"},{value:"CS084",text:"按比例0.5%",text:"11元"},{value:"CS085",text:"按比例1.85%"},{value:"CS086",text:"按比例0.5%",text:"10元"},{value:"CS087",text:"按比例0.5%",text:"27.5元"},{value:"CS088",text:"按比例0.5%",text:"5元"},{value:"CS089",text:"按比例4%"},{value:"CS090",text:"按比例0.3%",text:"3元"},{value:"CS091",text:"按比例1.65%"},{value:"CS092",text:"按比例1.6 %"},{value:"CSM001",text:"按比例1、202，最低0.5"},{value:"CSM010",text:"按比例1%－25元"},{value:"CSM011",text:"按比例1%－19元"},{value:"CSM012",text:"按比例0.48%"},{value:"CSM013",text:"按比例0.38%"},{value:"CSM015",text:"按比例0.317%"},{value:"CSM024",text:"按比例0.44%"},{value:"CSM026",text:"按比例0.27%"},{value:"CSM031",text:"按比例1%－28元"}],
    box0049:[{value:"",text:"请选择"},{value:"0",text:"是"},{value:"1",text:"否"}],
    box0050:[{value:"CS004",text:"CS004-分润方1得50%"},{value:"CS005",text:"CS005-分润方1得0.2元"},{value:"CS006",text:"CS006-分润方1得10%"},{value:"CS007",text:"CS007-分润方1得15%"},{value:"CS008",text:"CS008-分润方1得16%"},{value:"CS009",text:"CS009-分润方1得18%"},{value:"CS010",text:"CS010-分润方1得20%"},{value:"CS011",text:"CS011-分润方1得30%"},{value:"CS012",text:"CS012-分润方1得36%"},{value:"CS013",text:"CS013-甲87.5%乙10%"},{value:"CS015",text:"CS015-分润方1兜底"},{value:"CS016",text:"CS016-分润方2得10%，三兜底"},{value:"CS017",text:"CS017-分润方2得30%"},{value:"CS018",text:"CS018-分润方2兜底"},{value:"CS019",text:"CS019-分润方3得10%"},{value:"CS020",text:"CS020-分润方3得8%，二兜底"},{value:"CS021",text:"CS021-分润方3兜底"},{value:"CS094",text:"CS094-收单兜底"},{value:"CS107",text:"CS107-分润方2得剩余的30%"},{value:"CS108",text:"CS108-分润方一剩余的87.5%分润方二10%"},{value:"CS106",text:"CS106-分润方1得剩余90%"},{value:"CS105",text:"CS105-分润方1得剩余80%"},{value:"CS104",text:"CS104-分润方1得剩余75%"},{value:"CST002",text:"CST002-分润方一得余下40%"},{value:"CST004",text:"CST004-分润方1得剩余85%"},{value:"CST005",text:"CST005-分润方1得剩余35%"}],
    box0051:[{value:"",text:"请选择"},{value:"0",text:"不需要增加"},{value:"1",text:"需要增加"}],
    box0052:[{value:"",text:"请选择"},{value:"01",text:"5元/单笔"}],
    box0053:[{value:"",text:"请选择"},{value:"01",text:"1%-55元"},{value:"02",text:"1%-22元"}],
    box0054:[{value:"",text:"请选择"}],
    box0055:[{value:"",text:"请选择"},{value:"01",text:"0.5%"},{value:"02",text:"1%"},{value:"03",text:"2%"}],
    box0056:[{value:"",text:"请选择"},{value:"K301N",text:"K301N"},{value:"K301FZ",text:"K301FZ"},{value:"K320",text:"K320"},{value:"K320A",text:"K320A"},{value:"K350",text:"K350"},{value:"K360",text:"K360"},{value:"K370",text:"K370"}],	
    box0057:[{value:"",text:"请选择"},{value:"P58",text:"P58"},{value:"P80",text:"P80"},{value:"P80网络",text:"P80网络"},{value:"P60",text:"P60"},{value:"P78",text:"P78"},{value:"P90",text:"P90"},{value:"S60",text:"S60"},{value:"S90",text:"S90"},{value:"SP30",text:"SP30"},{value:"S58",text:"S58"},{value:"S80",text:"S80"},{value:"S78",text:"S78"}],	
    box0058:[{value:"",text:"请选择"},{value:"NL8510",text:"NL8510"},{value:"NL8080Y",text:"NL8080Y"},{value:"NL-GP730",text:"NL-GP730"}],
    box0059:[{value:"",text:"请选择"},{value:"KF605",text:"KF605"},{value:"KF900",text:"KF900"}],	
    box0060:[{value:"",text:"请选择"},{value:"HCD6228TSD(I)",text:"HCD6228TSD(I)"},{value:"HCD6228TSD(II)",text:"HCD6228TSD(II)"}],	
    box0061:[{value:"",text:"请选择"},{value:"9200(II)",text:"9200(II)"}],	
    box0062:[{value:"",text:""},{value:"0",text:"非连锁店"},{value:"1",text:"根总店"},{value:"2",text:"分店"}],
    box0063:[{value:"",text:""},{value:"9791",text:"大型批发商店资金归集业务"},{value:"9792",text:"缴费类业务"},{value:"9793",text:"历史遗留低扣率商户套用"},{value:"9794",text:"分公司自定义套用原因码1"},{value:"9795",text:"分公司自定义套用原因码2"},{value:"9796",text:"分公司自定义套用原因码3"},{value:"9797",text:"分公司自定义套用原因码4"},{value:"9798",text:"分公司自定义套用原因码5"},{value:"9799",text:"真实商户登记"}],
    box0064:[{value:"",text:"请选择"},{value:"0731",text:"长沙"},{value:"0730",text:"岳阳"}],
    box9992:[{value:"01",text:"长沙卡友"},{value:"02",text:"建设银行"},{value:"03",text:"株洲农信"}],
    box9993:[{value:"104",text:"61045500"},{value:"301",text:"03015510"},{value:"102",text:"01025500"},{value:"105",text:"01055500"},{value:"100",text:"01005500"},{value:"302",text:"03025510"},{value:"303",text:"03035510"},{value:"308",text:"03085510"},{value:"001",text:"00015500"},{value:"309",text:"03095510"},{value:"301",text:"03015570"},{value:"310",text:"03105510"},{value:"008",text:"00085500"},{value:"461",text:"04615510"},{value:"009",text:"00095500"},{value:"438",text:"14385500"},{value:"103",text:"01035500"},{value:"305",text:"03055510"},{value:"570",text:"05705500"},{value:"317",text:"03175510"},{value:"489",text:"04895510"}],
    /*box9993:{"104":"61045500","301":"03015510","102":"01025500","105":"01055500","100":"01005500","302":"03025510","303":"03035510","308":"03085510","001":"00015500","309":"03095510","301":"03015570","310":"03105510","008":"00085500","461":"04615510","009":"00095500","438":"14385500","103":"01035500","305":"03055510","570":"05705500","317":"03175510","489":"04895510"},    */
    box9994:[{value:"61045500",text:"中行湖南省分行"},{value:"03015510",text:"交通银行"},{value:"01025500",text:"工行湖南省分行"},{value:"01055500",text:"建行湖南省分行"},{value:"01005500",text:"邮储银行"},{value:"03025510",text:"中信银行"},{value:"03035510",text:"光大银行长沙分行"},{value:"03085510",text:"招商银行长沙分行"},{value:"00015500",text:"中国银联湖南分公司"},{value:"03095510",text:"兴业银行"},{value:"03015570",text:"交行岳阳分行商户"},{value:"03105510",text:"浦发银行"},{value:"00085500",text:"标准POSP"},{value:"04615510",text:"长沙银行"},{value:"00095501",text:"直联ATMP"},{value:"00085501",text:"本地POSP"},{value:"00095500",text:"标准ATMP"},{value:"14385500",text:"湖南省农村信用社联合社"},{value:"01035500",text:"湖南省农业银行"},{value:"03055510",text:"民生银行"},{value:"05705500",text:"华融湘江银行"},{value:"03175510",text:"渤海银行长沙分行"},{value:"04895510",text:"广东南粤银行长沙分行"}],
    box9996:[{value:"",text:"请选择"},{value:"5094",text:"贵重珠宝、首饰，钟表零售"},	{value:"5812",text:"就餐场所和餐馆"},	{value:"5813",text:"饮酒场所（酒吧、酒馆、夜总会、鸡尾酒大厅、迪斯科舞厅）"},	{value:"5970",text:"工艺美术商店"},	{value:"7011",text:"住宿服务（旅馆、酒店、汽车旅馆、度假村等）"},	{value:"7911",text:"歌舞厅"},	{value:"7933",text:"保龄球馆"},	{value:"7941",text:"商业体育场馆、职业体育俱乐部、运动场和体育推广公司"},	{value:"7996",text:"游乐园、马戏团、嘉年华、占卜"},	{value:"7997",text:"会员俱乐部（体育、娱乐、运动等）、乡村俱乐部以及私人高尔夫课程班"},	{value:"7998",text:"水族馆、海洋馆和海豚馆"},	{value:"5937",text:"古玩复制店"},	{value:"5950",text:"玻璃器皿和水晶饰品店"},	{value:"5971",text:"艺术商和画廊"},	{value:"7012",text:"分时使用的别墅或度假用房"},	{value:"7032",text:"运动和娱乐露营地"},	{value:"7033",text:"活动房车场及露营场所"},	{value:"7829",text:"电影和录像创作、发行"},	{value:"7922",text:"戏剧制片（不含电影）、演出和票务"},	{value:"7929",text:"未列入其他代码的乐队、文艺表演"},	{value:"7932",text:"台球、撞球场所"},	{value:"7992",text:"公共高尔夫球场"},	{value:"7994",text:"大型游戏机和游戏场所"},	{value:"1520",text:"一般承包商－住宅与商业楼"},	{value:"7013",text:"不动产代理——房地产经纪"},	{value:"5271",text:"活动房车销售商"},	{value:"5511",text:"汽车货车经销商－新旧车的销售、服务、维修、零件及出租"},	{value:"5521",text:"汽车货车经销商－专门从事旧车的销售、服务、维修、零件及出租"},	{value:"5551",text:"船只销售商"},	{value:"5561",text:"旅行拖车、娱乐用车销售商"},	{value:"5571",text:"摩托车商店和经销商"},	{value:"5592",text:"露营、房车销售商"},	{value:"5598",text:"雪车商"},	{value:"5599",text:"汽车、飞行器、农用机车综合经营商"},	{value:"5013",text:"机动车供应及零配件（批发商）"},	{value:"5021",text:"办公及商务家具（批发商）"},	{value:"5039",text:"未列入其他代码的建材批发（批发商）"},	{value:"5044",text:"办公、影印及微缩摄影器材（批发商）"},	{value:"5045",text:"计算机、计算机外围设备（批发商）"},	{value:"5046",text:"未列入其他代码的商用器材（批发商）"},	{value:"5047",text:"牙科/实验室/医疗/眼科医院器材和用品（批发商）"},	{value:"5051",text:"金属产品服务商和公司（批发商）"},	{value:"5065",text:"电器零件和设备（批发商）"},	{value:"5072",text:"三金器材及用品（批发商）"},	{value:"5074",text:"管道和供暖设备（批发商）"},	{value:"5111",text:"文具、办公用品、复印纸和书写纸（批发商）"},	{value:"5122",text:"药品、药品经营者（批发商）"},	{value:"5131",text:"布料、缝纫用品和其他纺织品（批发商）"},	{value:"5137",text:"男女及儿童制服和服装（批发商）"},	{value:"5139",text:"鞋类（批发商）"},	{value:"5172",text:"石油及石油产品（批发商）"},	{value:"5192",text:"书、期刊和报纸（批发商）"},	{value:"5193",text:"花木栽种用品、苗木和花卉（批发商）"},	{value:"5198",text:"油漆、清漆用品（批发商）"},	{value:"5998",text:"其他批发商"},	{value:"5933",text:"当铺"},	{value:"4112",text:"铁路客运"},	{value:"4511",text:"航空公司"},	{value:"5411",text:"大型仓储式超级市场"},	{value:"5542",text:"自助加油站"},	{value:"5722",text:"家用电器商店"},	{value:"5200",text:"大型仓储式家庭用品卖场"},	{value:"5300",text:"会员制批量零售店"},	{value:"5541",text:"加油站、服务站"},	{value:"4899",text:"有线和其他付费电视服务"},	{value:"4814",text:"电信服务，包括本地和长途电话、信用卡电话、磁卡电话和传真"},	{value:"8062",text:"公立医院"},	{value:"8211",text:"中小学校（公立）"},	{value:"8220",text:"普通高校（公立）"},	{value:"8398",text:"慈善和社会公益服务组织"},	{value:"9222",text:"罚款"},	{value:"9223",text:"保释金"},	{value:"9311",text:"纳税"},	{value:"9399",text:"未列入其他代码的政府服务（社会保障服务，国家强制）"},	{value:"9400",text:"使领馆收费"},	{value:"8651",text:"政治组织（政府机构）"},	{value:"9211",text:"法庭费用，包括赡养费和子女抚养费"},	{value:"4011",text:"铁路运输"},	{value:"4111",text:"本市和市郊通勤旅客运输（包括轮渡）"},	{value:"4119",text:"救护车服务"},	{value:"4121",text:"出租车服务"},	{value:"4131",text:"公路客运"},	{value:"4215",text:"快递服务（空运、地面运输或海运）"},	{value:"4225",text:"公共仓储服务－农产品、冷冻品和家用产品"},	{value:"4411",text:"轮船及巡游航线服务"},	{value:"4457",text:"出租船只"},	{value:"4582",text:"机场服务"},	{value:"4722",text:"旅行社"},	{value:"4789",text:"未列入其他代码的运输服务"},	{value:"4812",text:"通讯设备和电话销售"},	{value:"4816",text:"计算机网络/信息服务"},	{value:"5211",text:"木材和各类建材卖场"},	{value:"5231",text:"玻璃、油漆涂料、墙纸零售"},	{value:"5310",text:"折扣商店"},	{value:"5311",text:"百货商店"},	{value:"5399",text:"其他综合零售"},	{value:"5422",text:"各类肉类零售商"},	{value:"5441",text:"糖果及坚果商店"},	{value:"5451",text:"乳制品店、冷饮店"},	{value:"5462",text:"面包房、糕点商店"},	{value:"5532",text:"汽车轮胎经销商"},	{value:"5533",text:"汽车零配件商店"},	{value:"5611",text:"男子和男童服装及用品商店"},	{value:"5621",text:"妇女成衣商店"},	{value:"5631",text:"女性用品商店"},	{value:"5641",text:"婴儿、儿童服装店"},	{value:"5661",text:"鞋店"},	{value:"5681",text:"皮货店"},	{value:"5691",text:"成人成衣店"},	{value:"5698",text:"假发商店"},	{value:"5714",text:"帏帐、窗帘、室内装潢商店"},	{value:"5719",text:"各种家庭装饰专营店"},	{value:"5732",text:"电子设备商店"},	{value:"5734",text:"计算机软件商店"},	{value:"5814",text:"快餐店"},	{value:"5912",text:"药房、药店"},	{value:"5941",text:"体育用品店"},	{value:"5942",text:"书店"},	{value:"5943",text:"文具用品商店、各类办公用品商店"},	{value:"5946",text:"照相器材商店"},	{value:"5947",text:"礼品、卡片、装饰品、纪念品商店"},	{value:"5948",text:"箱包、皮具店"},	{value:"5972",text:"邮票和纪念币商店"},	{value:"5976",text:"假肢店（整形外科用品、辅助设备）"},	{value:"5977",text:"化妆品商店"},	{value:"5992",text:"花店"},	{value:"5993",text:"香烟、雪茄专卖店"},	{value:"5994",text:"报亭、报摊"},	{value:"6010",text:"金融机构－人工现金支付"},	{value:"6011",text:"金融机构－自动现金支付"},	{value:"6012",text:"金融机构－商品和服务"},	{value:"6051",text:"非金融机构－外币兑换、非电子转账的汇票、临时支付凭证和旅行支票"},	{value:"6211",text:"证券公司－经纪人和经销商"},	{value:"7217",text:"室内清洁服务（地毯、沙发、家具表面的清洁服务）"},	{value:"7221",text:"摄影工作室"},	{value:"7230",text:"美容理发店"},	{value:"7261",text:"殡葬服务"},	{value:"7273",text:"婚姻介绍及陪同服务"},	{value:"7277",text:"咨询服务－债务、婚姻和私人事务"},	{value:"7295",text:"家政服务"},	{value:"7296",text:"出租衣物－服装、制服和正式场合服装"},	{value:"7297",text:"按摩店"},	{value:"7298",text:"保健及美容SPA"},	{value:"7299",text:"未列入其他代码的其他个人服务"},	{value:"7311",text:"广告服务"},	{value:"7321",text:"消费者信用报告机构"},	{value:"7333",text:"商业摄影、工艺、绘图服务"},	{value:"7339",text:"速记、秘书服务（包括各类办公服务）"},	{value:"7349",text:"清洁、保养及门卫服务"},	{value:"7372",text:"计算机编程、数据处理和系统集成设计服务"},	{value:"7392",text:"管理、咨询和公共关系服务"},	{value:"7394",text:"设备、工具、家具和电器出租"},	{value:"7399",text:"未列入其他代码的商业服务"},	{value:"7512",text:"汽车出租"},	{value:"7513",text:"卡车及拖车出租"},	{value:"7519",text:"房车和娱乐车辆出租"},	{value:"7523",text:"停车场"},	{value:"7538",text:"汽车服务商店（非经销商）"},	{value:"7542",text:"洗车"},	{value:"7549",text:"拖车服务"},	{value:"7622",text:"电器设备维修"},	{value:"7623",text:"空调、制冷设备维修"},	{value:"7629",text:"电器设备、小家电维修"},	{value:"7641",text:"家具维修、翻新"},	{value:"7692",text:"焊接维修服务"},	{value:"7699",text:"各类维修店及相关服务"},	{value:"7832",text:"电影院"},	{value:"7841",text:"音像制品出租商店"},	{value:"7991",text:"旅游与展览"},	{value:"7995",text:"彩票销售"},	{value:"8011",text:"其他医疗卫生活动"},	{value:"8021",text:"牙科医生"},	{value:"8031",text:"正骨医生"},	{value:"8041",text:"按摩医生"},	{value:"8042",text:"眼科医生"},	{value:"8043",text:"光学产品、眼镜店"},	{value:"8050",text:"护理和照料服务"},	{value:"8071",text:"医学及牙科实验室"},	{value:"8099",text:"其他医疗保健服务"},	{value:"8111",text:"法律服务和律师事务所服务"},	{value:"8241",text:"函授学校（成人教育）"},	{value:"8299",text:"其他学校和教育服务"},	{value:"8351",text:"儿童保育服务（含学前教育）"},	{value:"8675",text:"汽车协会"},	{value:"8699",text:"其他会员组织"},	{value:"8911",text:"建筑、工程和测量服务"},	{value:"8912",text:"装修、装潢、园艺"},	{value:"8931",text:"会计、审计、财务服务"},	{value:"8999",text:"未列入其他代码的专业服务"},	{value:"0742",text:"兽医服务"},	{value:"0763",text:"农业合作"},	{value:"0780",text:"景观美化及园艺服务"},	{value:"4214",text:"货物搬运和托运—当地和长途，移动和存储公司，以及当地递送服务"},	{value:"4468",text:"船舶、海运服务提供商"},	{value:"4784",text:"路桥通行费"},	{value:"4821",text:"电报服务"},	{value:"5251",text:"五金商店"},	{value:"5261",text:"草坪、花园用品商店"},	{value:"5309",text:"免税商店"},	{value:"5331",text:"各类杂货店、便利店"},	{value:"5499",text:"各类食品店及专门食品零售店"},	{value:"5651",text:"家庭服装商店"},	{value:"5655",text:"运动服饰商店"},	{value:"5697",text:"裁缝、修补、改衣店"},	{value:"5699",text:"各类服装及饰物店"},	{value:"5712",text:"家具、家庭摆品、家用设备零售商"},	{value:"5713",text:"地板商店"},	{value:"5718",text:"壁炉、壁炉防护网及配件商店"},	{value:"5733",text:"音乐商店－乐器、钢琴、乐谱"},	{value:"5735",text:"音像制品商店"},	{value:"5921",text:"瓶装酒零售店"},	{value:"5931",text:"旧商品店、二手商品店"},	{value:"5935",text:"海上船只遇难救助"},	{value:"5940",text:"自行车商店"},	{value:"5945",text:"玩具、游戏店"},	{value:"5949",text:"纺织品及针织品零售"},	{value:"5962",text:"旅游相关服务直销"},	{value:"5963",text:"门对门销售"},	{value:"5964",text:"目录销售商户"},	{value:"5965",text:"目录、零售兼营商户"},	{value:"5966",text:"电话呼出直销"},	{value:"5967",text:"电话呼入直销"},	{value:"5968",text:"订阅/订购直销服务"},	{value:"5969",text:"其他直销商户"},	{value:"5973",text:"宗教品商店"},	{value:"5975",text:"助听器－销售、服务和用品"},	{value:"5978",text:"打字机商店—销售、服务和出租"},	{value:"5983",text:"燃料经销商－燃油、木材、煤炭和液化石油"},	{value:"5995",text:"宠物商店、宠物食品及用品"},	{value:"5996",text:"游泳池－销售、供应和服务"},	{value:"5997",text:"电动剃须刀商店－销售和服务"},	{value:"5999",text:"其他专门零售店"},	{value:"6513",text:"不动产管理－物业管理"},	{value:"7210",text:"洗衣店"},	{value:"7211",text:"洗熨服务（自助洗衣服务）"},	{value:"7216",text:"干洗店"},	{value:"7251",text:"修鞋店、擦鞋店、帽子清洗店"},	{value:"7276",text:"税收准备服务"},	{value:"7278",text:"购物服务及会所（贸易、经纪服务）"},	{value:"7338",text:"复印及绘图服务"},	{value:"7342",text:"灭虫及消毒服务"},	{value:"7361",text:"职业中介、临时工"},	{value:"7375",text:"信息检索服务"},	{value:"7379",text:"未列入其他代码的计算机维护和修理服务"},	{value:"7393",text:"侦探、保安、安全服务"},	{value:"7395",text:"照相洗印服务"},	{value:"7531",text:"车体维修店"},	{value:"7534",text:"轮胎翻新、维修店"},	{value:"7535",text:"汽车喷漆店"},	{value:"7993",text:"电子游戏供给"},	{value:"8049",text:"手足病医生"},	{value:"8244",text:"商业和文秘学校（中等专业学校）"},	{value:"8249",text:"贸易和职业学校（职业技能培训）"},	{value:"8641",text:"市民、社会及友爱组织"},	{value:"8661",text:"宗教组织"},	{value:"9402",text:"国家邮政服务"},	{value:"4900",text:"公共事业（电力、煤气、自来水、清洁服务）"},	{value:"6300",text:"保险销售、保险业和保险金"},	{value:"5960",text:"直销－保险批量代扣"},	{value:"5944",text:"银器店"},	{value:"5932",text:"古玩店——出售、维修及还原"},	{value:"7631",text:"手表、钟表和首饰维修店"},	{value:"5811",text:"包办伙食，宴会承包商"},	{value:"7999",text:"未列入其他代码的娱乐服务"},	{value:"4733",text:"大型景区售票"},	{value:"5398",text:"大型企业批发类商户"},	{value:"4458",text:"烟草配送"}],
    box9997:[{value:"",text:"请选择"},{value:"000",text:"浏阳市"},{value:"001",text:"宁乡县"},{value:"002",text:"长沙县"},{value:"003",text:"望城区"},{value:"004",text:"雨花区"},{value:"005",text:"天心区"},{value:"006",text:"芙蓉区"},{value:"007",text:"先导区"},{value:"008",text:"开福区"},{value:"009",text:"天元区"},{value:"010",text:"株洲县"},{value:"011",text:"攸县"},{value:"012",text:"醴陵市"},{value:"013",text:"炎陵县"},{value:"014",text:"茶陵县"},{value:"015",text:"株洲城郊"},{value:"016",text:"湘潭县"},{value:"017",text:"湘乡市"},{value:"018",text:"韶山市"},{value:"019",text:"岳塘区"},{value:"020",text:"雨湖区"},{value:"021",text:"衡南县"},{value:"022",text:"衡阳县"},{value:"023",text:"衡山县"},{value:"024",text:"衡东县"},{value:"025",text:"祁东县"},{value:"026",text:"常宁市"},{value:"027",text:"耒阳市"},{value:"028",text:"南岳区"},{value:"029",text:"雁峰区"},{value:"030",text:"石鼓区"},{value:"031",text:"珠晖区"},{value:"032",text:"蒸湘区"},{value:"033",text:"邵东县"},{value:"034",text:"新邵县"},{value:"035",text:"邵阳县"},{value:"036",text:"隆回县"},{value:"037",text:"洞口县"},{value:"038",text:"武冈市"},{value:"039",text:"绥宁县"},{value:"040",text:"新宁县"},{value:"041",text:"城步县"},{value:"042",text:"邵阳城郊"},{value:"043",text:"邵阳中心"},{value:"044",text:"临湘市"},{value:"045",text:"云溪区"},{value:"046",text:"汩罗市"},{value:"047",text:"岳阳楼区"},{value:"048",text:"君山区"},{value:"049",text:"岳阳县"},{value:"050",text:"华容县"},{value:"051",text:"平江县"},{value:"052",text:"湘阴县"},{value:"053",text:"南县"},{value:"054",text:"沅江市"},{value:"055",text:"安化县"},{value:"056",text:"桃江县"},{value:"057",text:"赫山区"},{value:"058",text:"资阳区"},{value:"059",text:"安乡县"},{value:"060",text:"汉寿县"},{value:"061",text:"澧县"},{value:"062",text:"鼎城区"},{value:"063",text:"临澧县"},{value:"064",text:"桃源县"},{value:"065",text:"石门县"},{value:"066",text:"武陵区"},{value:"067",text:"津市市"},{value:"068",text:"娄星区"},{value:"069",text:"双峰县"},{value:"070",text:"涟源市"},{value:"071",text:"冷水江市"},{value:"072",text:"新化县"},{value:"073",text:"苏仙区"},{value:"074",text:"北湖区"},{value:"075",text:"资兴市"},{value:"076",text:"安仁县"},{value:"077",text:"永兴县"},{value:"078",text:"桂阳县"},{value:"079",text:"嘉禾县"},{value:"080",text:"临武县"},{value:"081",text:"宜章县"},{value:"082",text:"桂东县"},{value:"083",text:"汝城县"},{value:"084",text:"零陵区"},{value:"085",text:"冷水滩区"},{value:"086",text:"祁阳县"},{value:"087",text:"东安县"},{value:"088",text:"道县"},{value:"089",text:"宁远县"},{value:"090",text:"江永县"},{value:"091",text:"江华县"},{value:"092",text:"蓝山县"},{value:"093",text:"新田县"},{value:"094",text:"双牌县"},{value:"095",text:"潇湘"},{value:"096",text:"鹤城区"},{value:"097",text:"中方县"},{value:"098",text:"辰溪县"},{value:"099",text:"沅陵县"},{value:"100",text:"溆浦县"},{value:"101",text:"麻阳县"},{value:"102",text:"芷江县"},{value:"103",text:"新晃县"},{value:"104",text:"会同县"},{value:"105",text:"洪江市"},{value:"106",text:"洪江区"},{value:"107",text:"靖州县"},{value:"108",text:"通道县"},{value:"109",text:"龙山县"},{value:"110",text:"永顺县"},{value:"111",text:"保靖县"},{value:"112",text:"花垣县"},{value:"113",text:"吉首市"},{value:"114",text:"凤凰县"},{value:"115",text:"泸溪县"},{value:"116",text:"古丈县"},{value:"117",text:"永定区"},{value:"118",text:"武陵源区"},{value:"119",text:"界桑植县"},{value:"120",text:"慈利县"},{value:"121",text:"南岳区"}],
 		box9998:[{value:"",text:"请选择"},{value:"00000",text:"公益类;不收费"},{value:"AX100",text:"消费类境内宾馆娱乐类;发卡1.4%，银联0.2%"},{value:"AX210",text:"房地产汽车典当拍卖类;发卡0.7%单笔最高40元，银联0.1%单笔最高5元"},{value:"AX230",text:"普通批发类;发卡0.7%单笔最高16元，银联0.1%单笔最高2元"},{value:"AX240",text:"大型企业批发;县乡优惠批发类;发卡0.35%单笔最高8元;银联0.05%单笔最高1元"},{value:"AX250",text:"烟草配送类;发卡0.35%单笔最高4元，银联0.05%单笔最高0.5元"},{value:"AX270",text:"县乡优惠房产汽车类;发卡0.35%，单笔最高20元,银联0.05%，单笔最高2.5元"},{value:"AX280",text:"县乡优惠三农商户类;发卡0.21%，单笔最高2.1元,银联0.03%，单笔最高0.3元"},{value:"AX300",text:"航空售票加油超市类;发卡0.35%，银联0.05%"},{value:"AX310",text:"县乡优惠超市加油类;发卡0.175%，银联0.025%"},{value:"AX500",text:"保险刷卡类;发卡0.21%，银联0.03%"},{value:"AX510",text:"保险批量代扣类;发卡1.4元/笔，银联0.2元/笔"},{value:"AX520",text:"公共事业类;发卡0.21元/笔，银联0.03元/笔"},{value:"AX900",text:"一般类;县乡优惠宾馆娱乐消费类;发卡0.7%，银联0.1%"},{value:"CI200",text:"湖南地区发卡方固定收取0.21元，银联0.03元"},{value:"CI201",text:"湖南地区发卡方收取交易金额的0.5%，银联兜底"},{value:"CI202",text:"湖南地区发卡方收取交易金额的1.4%上限14元，银联收取交易金额的1%上限2元"},{value:"CI203",text:"湖南地区发卡方收取商户回佣的20%，银联10%"},{value:"CI204",text:"湖南地区发卡方收取商户回佣的30%，银联30%"},{value:"CI205",text:"湖南地区发卡方收取商户回佣的40%，银联20%"},{value:"CI206",text:"湖南地区发卡方收取商户回佣的40%，银联40%"},{value:"CI207",text:"湖南地区发卡方收取商户回佣的60%，银联10%"},{value:"CI208",text:"湖南地区发卡方收取商户回佣的60%，银联20%"},{value:"CI209",text:"湖南地区发卡方收取商户回佣的60%，银联30%"},{value:"CI210",text:"湖南地区发卡方收取商户回佣的60%，银联兜底"},{value:"CI211",text:"湖南地区发卡方收取商户回佣的70%，银联10%"},{value:"CI212",text:"湖南地区发卡方收取商户回佣的70%，银联20%"},{value:"CI213",text:"湖南地区发卡方收取商户回佣的70%，银联22%"},{value:"CI700",text:"发卡银联分润算法,助农取款"}],
		box9999:[{value:"",text:"请选择"},{value:"430100",text:"长沙市"},{value:"430101",text:"市辖区"},{value:"430102",text:"芙蓉区"},{value:"430103",text:"天心区"},{value:"430104",text:"岳麓区"},{value:"430105",text:"开福区"},{value:"430111",text:"雨花区"},{value:"430121",text:"长沙县"},{value:"430122",text:"望城县"},{value:"430124",text:"宁乡县"},{value:"430181",text:"浏阳市"},{value:"430200",text:"株洲市"},{value:"430201",text:"市辖区"},{value:"430202",text:"荷塘区"},{value:"430203",text:"芦淞区"},{value:"430204",text:"石峰区"},{value:"430211",text:"天元区"},{value:"430221",text:"株洲县"},{value:"430223",text:"攸  县"},{value:"430224",text:"茶陵县"},{value:"430225",text:"炎陵县"},{value:"430281",text:"醴陵市"},{value:"430300",text:"湘潭市"},{value:"430301",text:"市辖区"},{value:"430302",text:"雨湖区"},{value:"430304",text:"岳塘区"},{value:"430321",text:"湘潭县"},{value:"430381",text:"湘乡市"},{value:"430382",text:"韶山市"},{value:"430400",text:"衡阳市"},{value:"430401",text:"市辖区"},{value:"430405",text:"珠晖区"},{value:"430406",text:"雁峰区"},{value:"430407",text:"石鼓区"},{value:"430408",text:"蒸湘区"},{value:"430412",text:"南岳区"},{value:"430421",text:"衡阳县"},{value:"430422",text:"衡南县"},{value:"430423",text:"衡山县"},{value:"430424",text:"衡东县"},{value:"430426",text:"祁东县"},{value:"430481",text:"耒阳市"},{value:"430482",text:"常宁市"},{value:"430500",text:"邵阳市"},{value:"430501",text:"市辖区"},{value:"430502",text:"双清区"},{value:"430503",text:"大祥区"},{value:"430511",text:"北塔区"},{value:"430521",text:"邵东县"},{value:"430522",text:"新邵县"},{value:"430523",text:"邵阳县"},{value:"430524",text:"隆回县"},{value:"430525",text:"洞口县"},{value:"430527",text:"绥宁县"},{value:"430528",text:"新宁县"},{value:"430529",text:"城步苗族自治县"},{value:"430581",text:"武冈市"},{value:"430600",text:"岳阳市"},{value:"430601",text:"市辖区"},{value:"430602",text:"岳阳楼区"},{value:"430603",text:"云溪区"},{value:"430611",text:"君山区"},{value:"430621",text:"岳阳县"},{value:"430623",text:"华容县"},{value:"430624",text:"湘阴县"},{value:"430626",text:"平江县"},{value:"430681",text:"汨罗市"},{value:"430682",text:"临湘市"},{value:"430700",text:"常德市"},{value:"430701",text:"市辖区"},{value:"430702",text:"武陵区"},{value:"430703",text:"鼎城区"},{value:"430721",text:"安乡县"},{value:"430722",text:"汉寿县"},{value:"430723",text:"澧  县"},{value:"430724",text:"临澧县"},{value:"430725",text:"桃源县"},{value:"430726",text:"石门县"},{value:"430781",text:"津市市"},{value:"430800",text:"张家界市"},{value:"430801",text:"市辖区"},{value:"430802",text:"永定区"},{value:"430811",text:"武陵源区"},{value:"430821",text:"慈利县"},{value:"430822",text:"桑植县"},{value:"430900",text:"益阳市"},{value:"430901",text:"市辖区"},{value:"430902",text:"资阳区"},{value:"430903",text:"赫山区"},{value:"430921",text:"南  县"},{value:"430922",text:"桃江县"},{value:"430923",text:"安化县"},{value:"430981",text:"沅江市"},{value:"431000",text:"郴州市"},{value:"431001",text:"市辖区"},{value:"431002",text:"北湖区"},{value:"431003",text:"苏仙区"},{value:"431021",text:"桂阳县"},{value:"431022",text:"宜章县"},{value:"431023",text:"永兴县"},{value:"431024",text:"嘉禾县"},{value:"431025",text:"临武县"},{value:"431026",text:"汝城县"},{value:"431027",text:"桂东县"},{value:"431028",text:"安仁县"},{value:"431081",text:"资兴市"},{value:"431100",text:"永州市"},{value:"431101",text:"市辖区"},{value:"431102",text:"芝山区"},{value:"431103",text:"冷水滩区"},{value:"431121",text:"祁阳县"},{value:"431122",text:"东安县"},{value:"431123",text:"双牌县"},{value:"431124",text:"道  县"},{value:"431125",text:"江永县"},{value:"431126",text:"宁远县"},{value:"431127",text:"蓝山县"},{value:"431128",text:"新田县"},{value:"431129",text:"江华瑶族自治县"},{value:"431200",text:"怀化市"},{value:"431201",text:"市辖区"},{value:"431202",text:"鹤城区"},{value:"431221",text:"中方县"},{value:"431222",text:"沅陵县"},{value:"431223",text:"辰溪县"},{value:"431224",text:"溆浦县"},{value:"431225",text:"会同县"},{value:"431226",text:"麻阳苗族自治县"},{value:"431227",text:"新晃侗族自治县"},{value:"431228",text:"芷江侗族自治县"},{value:"431229",text:"靖州苗族侗族自治县"},{value:"431230",text:"通道侗族自治县"},{value:"431281",text:"洪江市"},{value:"431300",text:"娄底市"},{value:"431301",text:"市辖区"},{value:"431302",text:"娄星区"},{value:"431321",text:"双峰县"},{value:"431322",text:"新化县"},{value:"431381",text:"冷水江市"},{value:"431382",text:"涟源市"},{value:"433100",text:"湘西土家族苗族自治州"},{value:"433101",text:"吉首市"},{value:"433122",text:"泸溪县"},{value:"433123",text:"凤凰县"},{value:"433124",text:"花垣县"},{value:"433125",text:"保靖县"},{value:"433126",text:"古丈县"},{value:"433127",text:"永顺县"},{value:"433130",text:"龙山县"}]
			};

function findText(boxid,value)
{
	var text;
	$.each(box[boxid],function(i,n){ 
         		if(n.value == value)
         		text = n.text;
		      }); 
		      return text;
}
function fullbox(id,data_id){
		 if(typeof(data_id)=="undefined")
		 {
			data_id = id;
		 }  
		     $("#"+id).html("");
         $.each(box[data_id],function(i,n){ 
         		var context;   
         	if(n.value!=""){
         		   context = n.value+"-"+n.text;   
         		}else{
         			 context = n.text;   
         			}
		        $("#"+id).append("<option value='" + n.value + "'>"+context+"</option>");
		      });       
}

function fullboxtext(id,data_id){
		 if(typeof(data_id)=="undefined")
		 {
			data_id = id;
		 }  
		     $("#"+id).html("");
         $.each(box[data_id],function(i,n){ 
         		var context;   
         	if(n.value!=""){
         		   context = n.text;   
         		}else{
         			 context = n.text;   
         			}
		        $("#"+id).append("<option value='" + n.value + "'>"+context+"</option>");
		      });       
}
  
  function fullinput(id,data_id,context){
		 if(typeof(data_id)=="undefined")
		 {
			data_id = id;
		 }  
		     $("#"+id).html("");
         $.each(box[data_id],function(i,n){ 
         	 if(n.value==context){
		        $("#"+id).val(n.text);
		      	}
		      });       
			}
  
	function clear(target){
		$('input,select,textarea', target).each(function(){
			var t = this.type, tag = this.tagName.toLowerCase();
			if (t == 'text' || t == 'password' || tag == 'textarea')
				this.value = '';
			else if (t == 'checkbox' || t == 'radio')
				this.checked = false;
			else if (tag == 'select')
				this.selectedIndex = -1;
			
		});
	}
  
  	function disable(target){
		$('input,select,textarea', target).each(function(){
			var t = this.type, tag = this.tagName.toLowerCase();
		     if (t != "button"){
				this.disabled="disabled";
			}
			   if(t=="textarea"){
						if(this.name=="reject_reason"){
					     this.disabled = false; 
					}
					
				};
		});
	}
   
   function checkNum(num)   
   {
   //验证必须是数字   
   //if(isNaN(num))   
   //{   
    //   alert("请输入数字！");   
    //   return false;   
   //}   
   //验证必须是4位   
    if(num.match(/\d/g).length!=15)   
    {   
        alert("您的输入必须为15位数字!");   
        return false;   
    }   
    if(num.match(/\d/g).length>15)   
    {   
        alert("您的输入超过了15位数字!");   
        return false;   
    }   
    if(num.match(/\d/g).length<15)   
    {   
        alert("您的输入不足了15位数字!");   
        return false;   
    }   
}  
  
    function duoqudao(flag){
    	 flag = flag.substring(0,1);
    	 if(flag=="0"){
    	 	$("#sp").val("");
    	 	$("#industry_code").val("");
    	 	$("#business_pro_mode").val("");
    	 	$("#application_type").val("");
    	 	$("#fine_mark").val("0");
    	 	$("#late_fee").val("");
    	 	$("#late_fee_type").val("");
    	 	$("#max_print").val("0");
    	 	$("#fixed_amount").val("0");
    	 	$("#minimum").val("0");
    	 	$("#ceiling").val("0");
    	 	$("#bench_rate").val("0");
    	 	$("#span_rate").val("0");
    	 	$("#pay_pass_meth").val("");
    	 	$("#liquidation_no").val("");
    	 	$("#principal_agent").val("");
    	 	$("#increase_mark").val("");
    	 	$("#mcht_clear_pro").val("");
    	 	$("#tax_category").val("");
    	 	$("#password_encryption").val("");
    	 	$("#pass_entry_index").val("0");
    	 	$("#channel_code").val("");
    	 	$("#tax_mark").val("0");
    	 	$("#collecting_mark").val("");
    	 	$("#rule_mark").val("");
    	 	}
    	 if(flag=="6"){
    	 	multi_channel_id="01";
    	 	$("#sp").val("00165501");
    	 	$("#industry_code").val("00165501");
    	 	$("#business_pro_mode").val("00");
    	 	$("#application_type").val("01");
    	 	$("#fine_mark").val("0");
    	 	$("#late_fee").val("");
    	 	$("#late_fee_type").val("");
    	 	$("#max_print").val("0");
    	 	$("#fixed_amount").val("0");    	 	
    	 	$("#minimum").val("0");
    	 	$("#ceiling").val("0");
    	 	$("#bench_rate").val("0");
    	 	$("#span_rate").val("0");
    	 	$("#pay_pass_meth").val("03");
    	 	$("#liquidation_no").val("");
    	 	$("#principal_agent").val("0");
    	 	$("#increase_mark").val("1");
    	 	$("#mcht_clear_pro").val("");
    	 	$("#tax_category").val("");
    	 	$("#password_encryption").val("0");
    	 	$("#pass_entry_index").val("");
    	 	$("#channel_code").val("");
    	 	$("#tax_mark").val("0");
    	 	$("#collecting_mark").val("1");
    	 	$("#rule_mark").val("0");
    	 	}
    }

     function miyao(flag){
     	var flag = flag.substring(0,1);
     	if(flag=="0"){
     		$("#term_encry_type").val("3");
     		$("#term_encry_key").val("1");
     		$("#term_key_length").val("02");
     		$("#pik").val("02");
     		$("#mak").val("01");
     		$("#mac").val("01");
     		$("#track_key_encry").val("01");
     		$("#term_trans_key").val("01");
     		$("#term_key1").val("");
     		$("#term_trans_key1").val("");
     		$("#term_key2").val("");
     		$("#term_trans_key2").val("");
     		$("#term_key3").val("");
     		$("#term_trans_key3").val("");
     		$("#cur_key_index").val("1-密钥一");
     		$("#key_index_no").val("0");
     		}
     	if(flag=="6"){
     		$("#term_encry_type").val("1");
     		$("#term_encry_key").val("0");
     		$("#term_key_length").val("01");
     		$("#pik").val("01");
     		$("#mak").val("01");
     		$("#mac").val("01");
     		$("#track_key_encry").val("01");
     		$("#term_trans_key").val("01");
     		$("#term_key1").val("");
     		$("#term_trans_key1").val("");
     		$("#term_key2").val("");
     		$("#term_trans_key2").val("");
     		$("#term_key3").val("");
     		$("#term_trans_key3").val("");
     		$("#cur_key_index").val("1-密钥一");
     		$("#key_index_no").val("118");
     		}
     	
     	
    }
    
    function qingsuan(flag){
     	var flag = flag.substring(0,1);
     	if(flag=="0"){
     		$("#term_encry_type").val("");
     		$("#term_encry_type").val("");
     		$("#term_encry_type").val("CS106");
     		$("#term_encry_type").val("");
     		}	
    }
    
    
    function check(id){
    	var context = $("#"+id).val();
    	 if(context==null||context==""){  
					        return false;  
    	}else{   
					        return true;   
					    }  
    	}
    	
    	//验证新增商户档案资料表单必填项

				function checkdata(){
			         var flag1,flag2,flag3,flag4;
			        if(check("mcht_name")==false){
			        	//   $("#mcht_name").val("商户名称不能为空！");
                   flag1=false;
                   flag2=false;
                 }else{ 
                   flag1=true;
                   flag2=true;
                 }
                 /*
              if(check(briefname)==false){
              	//  $("#brief_name").val("商户简称不能为空！");
                   flag2=false;
                 }else{ 
                   flag2=true;
                 }
                 */
              if(check("pan_name")==false){
              	//$("#pan_name").val("开户名不能为空！");
                   flag3=false;
                 }else{ 
                   flag3=true;
                 }
              if(check("bank_name")==false){
              //	$("#bank_name").val("开户行名称不能为空！");
                   flag4=false;
                 }else{ 
                   flag4=true;
				         	}		
				      if(flag1==true&&flag2==true&&flag3==true&&flag4==true){
				         		return true;
				         		}else{
				         			alert("必填项不能为空！");
				         		return false;
				         			}         
		        	}
		        	
		        	
		        		//验证新增银联商户参数表单必填项

				function checkyinliandata(){
			         var flag1,flag2,flag3,flag4,flag5,flag6,flag7,flag8,flag9,flag10,flag11,flag12;
			        if(check("mcht_no")==false){
			        	   //$("#mcht_no").val("不能为空！");
                   flag1=false;
                   flag2=false;
                 }else{ 
                   flag1=true;
                   flag2=true;
                 }
                 /*
              if(check(mchtname)==false){
			        	  // $("#mcht_name").val("不能为空！");
                   flag2=false;
                 }else{ 
                   flag2=true;
                 }
                 */
              if(check("brief_name")==false){
              	 // $("#brief_name").val("不能为空！");
                   flag3=false;
                 }else{ 
                   flag3=true;
                 }
              if(check("receive_ins")==false){
              //	$("#receive_ins").val("不能为空！");
                   flag4=false;
                 }else{ 
                   flag4=true;
                 }
              if(check("accept_ins")==false){
              	//$("#accept_ins").val("不能为空！");
                   flag5=false;
                 }else{ 
                   flag5=true;
				         	}	
				      if(check("platform_ins")==false){
			        	  // $("#platform_ins").val("不能为空！");
                   flag6=false;
                 }else{ 
                   flag6=true;
                 }
              if(check("access_ins")==false){
              	 // $("#access_ins").val("不能为空！");
                   flag7=false;
                 }else{ 
                   flag7=true;
                 }
              if(check("region")==false){
              	//$("#region").val("不能为空！");
                   flag8=false;
                 }else{ 
                   flag8=true;
                 }
              if(check("accept_region")==false){
              	//$("#accept_region").val("不能为空！");
                   flag9=false;
                 }else{ 
                   flag9=true;
				         	}
				       if(check("access_ins")==false){
              	 // $("#access_ins").val("不能为空！");
                   flag10=false;
                 }else{ 
                   flag10=true;
                 }
              if(check("region")==false){
              	//$("#region").val("不能为空！");
                   flag11=false;
                 }else{ 
                   flag11=true;
                 }
              if(check("accept_region")==false){
              	//$("#accept_region").val("不能为空！");
                   flag12=false;
                 }else{ 
                   flag12=true;
				         	}	   		
				      if(flag1==true&&flag2==true&&flag3==true&&flag4==true&&flag5==true&&flag6==true&&flag7==true&&flag8==true&&flag9==true&&flag10==true&&flag11==true&&flag12==true){
				         		return true;
				         		}else{
				         			alert("必填项不能为空！");
				         		return false;
				         			}         
		        	}
		        	
		        	
		        	//验证新增商户档案资料表单必填项

				function checkposdata(){
			         var flag1,flag2,flag3,flag4,flag5,flag6;
			        if(check("mcht_no")==false){
			        	//   $("#mcht_name").val("商户名称不能为空！");
                   flag1=false;
                 }else{ 
                   flag1=true;
                 }
                 
              if(check("term_no")==false){
              	//  $("#brief_name").val("商户简称不能为空！");
                   flag2=false;
                 }else{ 
                   flag2=true;
                 }
                 
              if(check("terminal_no")==false){
              	//$("#pan_name").val("开户名不能为空！");
                   flag3=false;
                 }else{ 
                   flag3=true;
                 }
              if(check("receive_ins")==false){
              //	$("#bank_name").val("开户行名称不能为空！");
                   flag4=false;
                 }else{ 
                   flag4=true;
				         	}	
				         	
				         	if(check("region")==false){
              //	$("#bank_name").val("开户行名称不能为空！");
                   flag5=false;
                 }else{ 
                   flag5=true;
				         	}		
				         	if(check("cur_key_index")==false){
              //	$("#bank_name").val("开户行名称不能为空！");
                   flag6=false;
                 }else{ 
                   flag6=true;
				         	}			
				      if(flag1==true&&flag2==true&&flag3==true&&flag4==true&&flag5==true&&flag6==true){
				         		return true;
				         		}else{
				         			alert("必填项不能为空！");
				         		return false;
				         			}         
		        	}
		        	
		     //验证影印件上传资料表单必填项
		        function checkyingyindata(){
			         var flag1,flag2;
			        if(check("mcht_id")==false){
			        	//   $("#mcht_id").val("商户档案编号不能为空！");
                   flag1=false;
                 }else{ 
                   flag1=true;
                 }
                  
             /* if(check("filetypename")==false){
              	  $("#filetypename").val("文件类型名称不能为空！");
                  flag2=false;
                 }else{ 
                   flag2=true;
                 }*/
             if(flag1==true){
				         		return true;
				         		}else{
				         			alert("必填项不能为空！");
				         		return false;
				         			}   
               }