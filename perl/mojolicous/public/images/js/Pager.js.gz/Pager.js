﻿var pageNum = 1;
//第一页
function FirstPage() {
    $("#drop_page").val("1");
    BindData();
}
//上一页
function PrePage() {
    var page = $("#drop_page").val();
    page--;
    if (page < 1) { page = 1; }
    $("#drop_page").val(page);
    BindData();
}
//下一页
function NextPage() {
    var page = $("#drop_page").val();
    page++;
    if (page > pageNum) { page = pageNum; }
    $("#drop_page").val(page);
    BindData();

}
//最后一页
function LastPage() {
    $("#drop_page").val(pageNum);
    BindData();
}
//跳转页
function ChangedPage() {
    BindData();
}
//绑定分页导航
function BindPagerBtn(total, PageIndex) {
    //如果未返回先读取HTML控件中PageIndex
    if (PageIndex == "" || PageIndex == null || PageIndex == "undefined") {
        PageIndex = $("#drop_page").val();
    }
    //如果是首页载入页面，没有HTML控件，则默认为第一页
    if (PageIndex == "" || PageIndex == null || PageIndex == "undefined") {
        PageIndex = 1;
    }

    //计算页数
    pageNum = total / pageSize
    if (pageNum >= 0) {
        pageNum = Math.floor(pageNum)
    }
    else {
        pageNum = 1;
    }
    if (total % pageSize > 0) pageNum++;

    var strHtml = "<div>共<span class=reds>" + total + "</span>条记录(<span class=reds>" + pageSize + "</span>条/页) 第<span class=reds>" + PageIndex + "</span>页</div><div>";

    //首页
    if (PageIndex <= 1) {
        strHtml += "<a href=\"javascript:void(0)\" disabled=\"true\">[首页]</a>";
    }
    else {
        strHtml += "<a href=\"javascript:FirstPage()\">[首页]</a>";
    }
    //上一页
    if (PageIndex <= 1) {
        strHtml += "<a href=\"javascript:void(0)\" disabled=\"true\">[上一页]</a>";
    }
    else {
        strHtml += "<a href=\"javascript:PrePage()\">[上一页]</a>";
    }
    //下一页
    if (PageIndex >= pageNum) {
        strHtml += "<a href=\"javascript:void(0)\" disabled=\"true\">[下一页]</a>";
    }
    else {
        strHtml += "<a href=\"javascript:NextPage()\">[下一页]</a>";
    }
    //末页
    if (PageIndex >= pageNum) {
        strHtml += "<a href=\"javascript:void(0)\" disabled=\"true\">[末页]</a>";
    }
    else {
        strHtml += "<a href=\"javascript:LastPage()\">[末页]</a>";
    }
    //跳转
    strHtml += "<select id=\"drop_page\" onchange=\"ChangedPage()\">";
    for (var i = 1; i <= pageNum; i++) {
        if (i == PageIndex) {
            strHtml += "<option value=\"" + i + "\" selected>第" + i + "页</option>";
        }
        else {
            strHtml += "<option value=\"" + i + "\">第" + i + "页</option>";
        }
    }
    strHtml += "</select></div>";
    $("#div_Pager").html(strHtml);
}
