﻿var city_data = "110000|001组长,110100|001组员,110200|002组员,110300|003组员,120000|002组长,120100|004组员,120200|005组员,120300|006组员,130000|003组长,130100|007组员,130200|008组员,130300|009组员,"
/*
//填充省级行政单位
function full_city() {
    city_arr = city_data.split(",");
    var cs_i = 1;
    for (i = 1; i <= city_arr.length; i++) {
        //document.write(city_arr[i-1].substring(2,6)+"<br>");
        if (city_arr[i - 1].substring(2, 6) == "0000") {
            document.all.city1.options[cs_i] = new Option(city_arr[i - 1].substring(7, city_arr[i - 1].length), city_arr[i - 1].substring(0, 6));
            cs_i++;
        }
    }
    //getCityValue();
}
//省级行政单位改变时填充地级行政单位
function city_1(city1_str) {
    fcs_i = 1;
    var str_city1 = city1_str / 10000;
    //alert(str_city1);
    for (i = 1; i <= city_arr.length; i++) {
        if (city_arr[i - 1].substring(0, 2) == str_city1 && city_arr[i - 1].substring(2, 6) != "0000" && city_arr[i - 1].substring(4, 6) == "00") {
            document.all.city2.options[fcs_i] = new Option(city_arr[i - 1].substring(7, city_arr[i - 1].length), city_arr[i - 1].substring(0, 6));
            fcs_i++;
        }
    }
    document.all.city2.length = fcs_i;
}
//地级行政单位改变时填充县级行政单位
function city_2(city2_str) {
    fcs_i = 1;
    var str_city2 = city2_str / 100;
    //alert(str_city1);
    for (i = 1; i <= city_arr.length; i++) {
        if (city_arr[i - 1].substring(0, 4) == str_city2 && city_arr[i - 1].substring(4, 6) != "00") {
            document.all.city3.options[fcs_i] = new Option(city_arr[i - 1].substring(7, city_arr[i - 1].length), city_arr[i - 1].substring(0, 6));
            fcs_i++;
        }
    }
    document.all.city3.length = fcs_i;
}
//填充实际需要使用的INPUT的值
function getCityValue() {
    document.all.city_value.value = "";

    if (document.all.city1.value != "")
    { document.all.city_value.value = document.all.city1.value; }

    if (document.all.city2.value != "")
    { document.all.city_value.value = document.all.city2.value; }
    if (document.all.city3.value != "")
    { document.all.city_value.value = document.all.city3.value; }
}
//根据城市数据的默认值选种选择项
function selectedValue() {
    //显示第一个地区
    for (i = 1; i <= document.all.city1.length; i++) {
        if (document.all.city1.options[i - 1].value.substring(0, 2) == document.all.city_value.value.substring(0, 2)) {
            document.all.city1.selectedIndex = i - 1;
        }

    }
    city_1(document.all.city1.value);
    //显示第二个地区
    for (i = 1; i <= document.all.city2.length; i++) {
        if (document.all.city2.options[i - 1].value.substring(0, 4) == document.all.city_value.value.substring(0, 4)) {
            document.all.city2.selectedIndex = i - 1;
        }
    }
    city_2(document.all.city2.value);
    //显示第三个地区
    for (i = 1; i <= document.all.city3.length; i++) {
        if (document.all.city3.options[i - 1].value == document.all.city_value.value) {
            document.all.city3.selectedIndex = i - 1;
        }
    }
}
*/
//--------------------------------------------------------------
//填充省级行政单位
function full_city1() {
    city_arr = city_data.split(",");
    var cs_i = 1;
    for (i = 1; i <= city_arr.length; i++) {
        //document.write(city_arr[i-1].substring(2,6)+"<br>");
        if (city_arr[i - 1].substring(2, 6) == "0000") {
            document.all.city11.options[cs_i] = new Option(city_arr[i - 1].substring(7, city_arr[i - 1].length), city_arr[i - 1].substring(0, 6));
            cs_i++;
        }
    }
    //getCityValue();
}
//省级行政单位改变时填充地级行政单位
function city_11(city1_str) {
    fcs_i = 1;
    var str_city1 = city1_str / 10000;
    //alert(str_city1);
    for (i = 1; i <= city_arr.length; i++) {
        if (city_arr[i - 1].substring(0, 2) == str_city1 && city_arr[i - 1].substring(2, 6) != "0000" && city_arr[i - 1].substring(4, 6) == "00") {
            document.all.city22.options[fcs_i] = new Option(city_arr[i - 1].substring(7, city_arr[i - 1].length), city_arr[i - 1].substring(0, 6));
            fcs_i++;
        }
    }
    document.all.city22.length = fcs_i;
}
/*
//地级行政单位改变时填充县级行政单位
function city_22(city2_str) {
    fcs_i = 1;
    var str_city2 = city2_str / 100;
    //alert(str_city1);
    for (i = 1; i <= city_arr.length; i++) {
        if (city_arr[i - 1].substring(0, 4) == str_city2 && city_arr[i - 1].substring(4, 6) != "00") {
            document.all.city33.options[fcs_i] = new Option(city_arr[i - 1].substring(7, city_arr[i - 1].length), city_arr[i - 1].substring(0, 6));
            fcs_i++;
        }
    }
    document.all.city33.length = fcs_i;
}
//填充实际需要使用的INPUT的值
function getCityValue1() {
    document.all.city_value1.value = "";

    if (document.all.city11.value != "")
    { document.all.city_value1.value = document.all.city11.value; }

    if (document.all.city22.value != "")
    { document.all.city_value1.value = document.all.city22.value; }
    if (document.all.city33.value != "")
    { document.all.city_value1.value = document.all.city33.value; }
}
//根据城市数据的默认值选种选择项
function selectedValue1() {
    //显示第一个地区
    for (i = 1; i <= document.all.city11.length; i++) {
        if (document.all.city11.options[i - 1].value.substring(0, 2) == document.all.city_value1.value.substring(0, 2)) {
            document.all.city11.selectedIndex = i - 1;
        }

    }
    city_11(document.all.city11.value);
    //显示第二个地区
    for (i = 1; i <= document.all.city22.length; i++) {
        if (document.all.city22.options[i - 1].value.substring(0, 4) == document.all.city_value1.value.substring(0, 4)) {
            document.all.city22.selectedIndex = i - 1;
        }
    }
    city_22(document.all.city22.value);
    //显示第三个地区
    for (i = 1; i <= document.all.city33.length; i++) {
        if (document.all.city33.options[i - 1].value == document.all.city_value1.value) {
            document.all.city33.selectedIndex = i - 1;
        }
    }
}

String.prototype.GetPCD = function() {
    var str = this;
    if (str == null || str.length < 6) {
        return;
    }
    var p = "";
    var c = "";
    var d = "";

    var arrArea = city_data.split(",");
    for (i = 1; i <= arrArea.length; i++) {
        if (arrArea[i - 1].substring(0, 6) == str.substring(0, 2) + "0000") {
            p = arrArea[i - 1].substring(7, arrArea[i - 1].length)
        }

        if (arrArea[i - 1].substring(0, 6) == str.substring(0, 4) + "00") {
            c = arrArea[i - 1].substring(7, arrArea[i - 1].length)
        }

        if (arrArea[i - 1].substring(0, 6) == str) {
            d = arrArea[i - 1].substring(7, arrArea[i - 1].length)
        }
    }

    return p + " " + c + " " + d;
}


function FGetPCD(str) {
    if (str == null || str.length < 6) {
        return;
    }
    var p = "";
    var c = "";
    var d = "";

    var arrArea = city_data.split(",");
    for (i = 1; i <= arrArea.length; i++) {
        if (arrArea[i - 1].substring(0, 6) == str.substring(0, 2) + "0000") {
            p = arrArea[i - 1].substring(7, arrArea[i - 1].length)
        }

        if (arrArea[i - 1].substring(0, 6) == str.substring(0, 4) + "00") {
            c = arrArea[i - 1].substring(7, arrArea[i - 1].length)
        }

        if (arrArea[i - 1].substring(0, 6) == str) {
            d = arrArea[i - 1].substring(7, arrArea[i - 1].length)
        }
    }

    return p + " " + c + " " + d;
}
*/