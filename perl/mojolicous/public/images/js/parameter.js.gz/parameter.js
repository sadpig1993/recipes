
		var data = {};
		data.fc = "0100000R";
		data.data = {};
		data.data.where = {};data.data.where.box = "0013";	  
		var params = $.toJSON(data);
		  $.ajax({
			  url:'/combobox.action',
			  type:'post',
			  dataType:'json',
			  data:params,
			  contentType:'application/json',
			  success:function(data){
				if (data.success == "00") {
                    var datas = data.data.rows;
                   //�̻���������
					 $.each(datas, function(i, m) {
                        $("#sales_manager").append($("<option value='" + m.key + "'></option>").html(m.value));
                    })

                }
                else {
                    alert(data.msg);
                }
				  },
			   error: function(jqXHR, textStatus, errorThrown) {
                alert("error:" + errorThrown.message);
            }
			  });

 
 
		var data = {};
		data.fc = "0100000R";
		data.data = {};
		data.data.where = {};data.data.where.box = "0014";	  
		var params = $.toJSON(data);
		  $.ajax({
			  url:'/combobox.action',
			  type:'post',
			  dataType:'json',
			  data:params,
			  contentType:'application/json',
			  success:function(data){
				if (data.success == "00") {
                    var datas = data.data.rows;
                   //���Ҵ���
					 $.each(datas, function(i, m) {
                        $("#country_code").append($("<option value='" + m.key + "'></option>").html(m.value));
                    })

                }
                else {
                    alert(data.msg);
                }
				  },
			   error: function(jqXHR, textStatus, errorThrown) {
                alert("error:" + errorThrown.message);
            }
			  });



		var data = {};
		data.fc = "0100000R";
		data.data = {};
		data.data.where = {};data.data.where.box = "0015";	  
		var params = $.toJSON(data);
		  $.ajax({
			  url:'/combobox.action',
			  type:'post',
			  dataType:'json',
			  data:params,
			  contentType:'application/json',
			  success:function(data){
				if (data.success == "00") {
                    var datas = data.data.rows;
                   //�����̻�����
					 $.each(datas, function(i, m) {
                        $("#merchant_type").append($("<option value='" + m.key + "'></option>").html(m.value));
                    })

                }
                else {
                    alert(data.msg);
                }
				  },
			   error: function(jqXHR, textStatus, errorThrown) {
                alert("error:" + errorThrown.message);
            }
			  });

 
 
		var data = {};
		data.fc = "0100000R";
		data.data = {};
		data.data.where = {};data.data.where.box = "0016";	  
		var params = $.toJSON(data);
		  $.ajax({
			  url:'/combobox.action',
			  type:'post',
			  dataType:'json',
			  data:params,
			  contentType:'application/json',
			  success:function(data){
				if (data.success == "00") {
                    var datas = data.data.rows;
                   //��ʵ�̻�����
					 $.each(datas, function(i, m) {
                        $("#realmerchant_type").append($("<option value='" + m.key + "'></option>").html(m.value));
                    })

                }
                else {
                    alert(data.msg);
                }
				  },
			   error: function(jqXHR, textStatus, errorThrown) {
                alert("error:" + errorThrown.message);
            }
			  });

 
 
  
		var data = {};
		data.fc = "0100000R";
		data.data = {};
		data.data.where = {};data.data.where.box = "0017";	  
		var params = $.toJSON(data);
		  $.ajax({
			  url:'/combobox.action',
			  type:'post',
			  dataType:'json',
			  data:params,
			  contentType:'application/json',
			  success:function(data){
				if (data.success == "00") {
                    var datas = data.data.rows;
                   //�̻����
					 $.each(datas, function(i, m) {
                        $("#merchant_groups").append($("<option value='" + m.key + "'></option>").html(m.value));
                    })

                }
                else {
                    alert(data.msg);
                }
				  },
			   error: function(jqXHR, textStatus, errorThrown) {
                alert("error:" + errorThrown.message);
            }
			  });



		var data = {};
		data.fc = "0100000R";
		data.data = {};
		data.data.where = {};data.data.where.box = "0018";	  
		var params = $.toJSON(data);
		  $.ajax({
			  url:'/combobox.action',
			  type:'post',
			  dataType:'json',
			  data:params,
			  contentType:'application/json',
			  success:function(data){
				if (data.success == "00") {
                    var datas = data.data.rows;
                   //�����̻�����ԭ��
					 $.each(datas, function(i, m) {
                        $("#merchant_typereason").append($("<option value='" + m.key + "'></option>").html(m.value));
                    })

                }
                else {
                    alert(data.msg);
                }
				  },
			   error: function(jqXHR, textStatus, errorThrown) {
                alert("error:" + errorThrown.message);
            }
			  });

 
 
 
		var data = {};
		data.fc = "0100000R";
		data.data = {};
		data.data.where = {};data.data.where.box = "0019";	  
		var params = $.toJSON(data);
		  $.ajax({
			  url:'/combobox.action',
			  type:'post',
			  dataType:'json',
			  data:params,
			  contentType:'application/json',
			  success:function(data){
				if (data.success == "00") {
                    var datas = data.data.rows;
                   //�̻�״̬
					 $.each(datas, function(i, m) {
                        $("#merchant_status").append($("<option value='" + m.key + "'></option>").html(m.value));
                    })

                }
                else {
                    alert(data.msg);
                }
				  },
			   error: function(jqXHR, textStatus, errorThrown) {
                alert("error:" + errorThrown.message);
            }
			  });

 
 
 
		var data = {};
		data.fc = "0100000R";
		data.data = {};
		data.data.where = {};data.data.where.box = "0020";	  
		var params = $.toJSON(data);
		  $.ajax({
			  url:'/combobox.action',
			  type:'post',
			  dataType:'json',
			  data:params,
			  contentType:'application/json',
			  success:function(data){
				if (data.success == "00") {
                    var datas = data.data.rows;
                   //�̻�������������
					 $.each(datas, function(i, m) {
                        $("#merchant_type_applied").append($("<option value='" + m.key + "'></option>").html(m.value));
                    })

                }
                else {
                    alert(data.msg);
                }
				  },
			   error: function(jqXHR, textStatus, errorThrown) {
                alert("error:" + errorThrown.message);
            }
			  });

 
 
 
		var data = {};
		data.fc = "0100000R";
		data.data = {};
		data.data.where = {};data.data.where.box = "0021";	  
		var params = $.toJSON(data);
		  $.ajax({
			  url:'/combobox.action',
			  type:'post',
			  dataType:'json',
			  data:params,
			  contentType:'application/json',
			  success:function(data){
				if (data.success == "00") {
                    var datas = data.data.rows;
                   //�����������
					 $.each(datas, function(i, m) {
                        $("#special_control").append($("<option value='" + m.key + "'></option>").html(m.value));
                    })

                }
                else {
                    alert(data.msg);
                }
				  },
			   error: function(jqXHR, textStatus, errorThrown) {
                alert("error:" + errorThrown.message);
            }
			  });

 
 
 
		var data = {};
		data.fc = "0100000R";
		data.data = {};
		data.data.where = {};data.data.where.box = "0022";	  
		var params = $.toJSON(data);
		  $.ajax({
			  url:'/combobox.action',
			  type:'post',
			  dataType:'json',
			  data:params,
			  contentType:'application/json',
			  success:function(data){
				if (data.success == "00") {
                    var datas = data.data.rows;
                   //���ӷ�ʽ
					 $.each(datas, function(i, m) {
                        $("#connection_mode").append($("<option value='" + m.key + "'></option>").html(m.value));
                    })

                }
                else {
                    alert(data.msg);
                }
				  },
			   error: function(jqXHR, textStatus, errorThrown) {
                alert("error:" + errorThrown.message);
            }
			  });




		var data = {};
		data.fc = "0100000R";
		data.data = {};
		data.data.where = {};data.data.where.box = "0023";	  
		var params = $.toJSON(data);
		  $.ajax({
			  url:'/combobox.action',
			  type:'post',
			  dataType:'json',
			  data:params,
			  contentType:'application/json',
			  success:function(data){
				if (data.success == "00") {
                    var datas = data.data.rows;
                   //Ĭ�Ͻ��ױ���
					 $.each(datas, function(i, m) {
                        $("#trading_currency").append($("<option value='" + m.key + "'></option>").html(m.value));
                    })

                }
                else {
                    alert(data.msg);
                }
				  },
			   error: function(jqXHR, textStatus, errorThrown) {
                alert("error:" + errorThrown.message);
            }
			  });

 
 
		var data = {};
		data.fc = "0100000R";
		data.data = {};
		data.data.where = {};data.data.where.box = "0024";	  
		var params = $.toJSON(data);
		  $.ajax({
			  url:'/combobox.action',
			  type:'post',
			  dataType:'json',
			  data:params,
			  contentType:'application/json',
			  success:function(data){
				if (data.success == "00") {
                    var datas = data.data.rows;
                   //��ҵ����
					 $.each(datas, function(i, m) {
                        $("#company_property").append($("<option value='" + m.key + "'></option>").html(m.value));
                    })

                }
                else {
                    alert(data.msg);
                }
				  },
			   error: function(jqXHR, textStatus, errorThrown) {
                alert("error:" + errorThrown.message);
            }
			  });

 

 
		var data = {};
		data.fc = "0100000R";
		data.data = {};
		data.data.where = {};data.data.where.box = "0025";	  
		var params = $.toJSON(data);
		  $.ajax({
			  url:'/combobox.action',
			  type:'post',
			  dataType:'json',
			  data:params,
			  contentType:'application/json',
			  success:function(data){
				if (data.success == "00") {
                    var datas = data.data.rows;
                   //���˴���֤������
					 $.each(datas, function(i, m) {
                        $("#legal_documents").append($("<option value='" + m.key + "'></option>").html(m.value));
                    })

                }
                else {
                    alert(data.msg);
                }
				  },
			   error: function(jqXHR, textStatus, errorThrown) {
                alert("error:" + errorThrown.message);
            }
			  });


 
		var data = {};
		data.fc = "0100000R";
		data.data = {};
		data.data.where = {};data.data.where.box = "0026";	  
		var params = $.toJSON(data);
		  $.ajax({
			  url:'/combobox.action',
			  type:'post',
			  dataType:'json',
			  data:params,
			  contentType:'application/json',
			  success:function(data){
				if (data.success == "00") {
                    var datas = data.data.rows;
                   //ע���ʱ�����
					 $.each(datas, function(i, m) {
                        $("#capital_currency").append($("<option value='" + m.key + "'></option>").html(m.value));
                    })

                }
                else {
                    alert(data.msg);
                }
				  },
			   error: function(jqXHR, textStatus, errorThrown) {
                alert("error:" + errorThrown.message);
            }
			  });

 
 
		var data = {};
		data.fc = "0100000R";
		data.data = {};
		data.data.where = {};data.data.where.box = "0027";	  
		var params = $.toJSON(data);
		  $.ajax({
			  url:'/combobox.action',
			  type:'post',
			  dataType:'json',
			  data:params,
			  contentType:'application/json',
			  success:function(data){
				if (data.success == "00") {
                    var datas = data.data.rows;
                   //�ʽ����˷�ʽ
					 $.each(datas, function(i, m) {
                        $("#funds_accounted").append($("<option value='" + m.key + "'></option>").html(m.value));
                    })

                }
                else {
                    alert(data.msg);
                }
				  },
			   error: function(jqXHR, textStatus, errorThrown) {
                alert("error:" + errorThrown.message);
            }
			  });

 
 
 
		var data = {};
		data.fc = "0100000R";
		data.data = {};
		data.data.where = {};data.data.where.box = "0028";	  
		var params = $.toJSON(data);
		  $.ajax({
			  url:'/combobox.action',
			  type:'post',
			  dataType:'json',
			  data:params,
			  contentType:'application/json',
			  success:function(data){
				if (data.success == "00") {
                    var datas = data.data.rows;
                   //�̵�����ģʽ
					 $.each(datas, function(i, m) {
                        $("#store_liquidation").append($("<option value='" + m.key + "'></option>").html(m.value));
                    })

                }
                else {
                    alert(data.msg);
                }
				  },
			   error: function(jqXHR, textStatus, errorThrown) {
                alert("error:" + errorThrown.message);
            }
			  });

 
 
		var data = {};
		data.fc = "0100000R";
		data.data = {};
		data.data.where = {};data.data.where.box = "0029";	  
		var params = $.toJSON(data);
		  $.ajax({
			  url:'/combobox.action',
			  type:'post',
			  dataType:'json',
			  data:params,
			  contentType:'application/json',
			  success:function(data){
				if (data.success == "00") {
                    var datas = data.data.rows;
                   //�ʽ𻮸�����
					 $.each(datas, function(i, m) {
                        $("#funding_cycle").append($("<option value='" + m.key + "'></option>").html(m.value));
                    })

                }
                else {
                    alert(data.msg);
                }
				  },
			   error: function(jqXHR, textStatus, errorThrown) {
                alert("error:" + errorThrown.message);
            }
			  });

 
  
		var data = {};
		data.fc = "0100000R";
		data.data = {};
		data.data.where = {};data.data.where.box = "0030";	  
		var params = $.toJSON(data);
		  $.ajax({
			  url:'/combobox.action',
			  type:'post',
			  dataType:'json',
			  data:params,
			  contentType:'application/json',
			  success:function(data){
				if (data.success == "00") {
                    var datas = data.data.rows;
                   //�渶�ز�����
					 $.each(datas, function(i, m) {
                        $("#advance_covering").append($("<option value='" + m.key + "'></option>").html(m.value));
                    })

                }
                else {
                    alert(data.msg);
                }
				  },
			   error: function(jqXHR, textStatus, errorThrown) {
                alert("error:" + errorThrown.message);
            }
			  });

 
 
		var data = {};
		data.fc = "0100000R";
		data.data = {};
		data.data.where = {};data.data.where.box = "0031";	  
		var params = $.toJSON(data);
		  $.ajax({
			  url:'/combobox.action',
			  type:'post',
			  dataType:'json',
			  data:params,
			  contentType:'application/json',
			  success:function(data){
				if (data.success == "00") {
                    var datas = data.data.rows;
                   //�̻��˻�����
					 $.each(datas, function(i, m) {
                        $("#account_currency").append($("<option value='" + m.key + "'></option>").html(m.value));
                    })

                }
                else {
                    alert(data.msg);
                }
				  },
			   error: function(jqXHR, textStatus, errorThrown) {
                alert("error:" + errorThrown.message);
            }
			  });

 
 
		var data = {};
		data.fc = "0100000R";
		data.data = {};
		data.data.where = {};data.data.where.box = "0032";	  
		var params = $.toJSON(data);
		  $.ajax({
			  url:'/combobox.action',
			  type:'post',
			  dataType:'json',
			  data:params,
			  contentType:'application/json',
			  success:function(data){
				if (data.success == "00") {
                    var datas = data.data.rows;
                   //������������
					 $.each(datas, function(i, m) {
                        $("#principal_liquidation").append($("<option value='" + m.key + "'></option>").html(m.value));
                    })

                }
                else {
                    alert(data.msg);
                }
				  },
			   error: function(jqXHR, textStatus, errorThrown) {
                alert("error:" + errorThrown.message);
            }
			  });

 
  
		var data = {};
		data.fc = "0100000R";
		data.data = {};
		data.data.where = {};data.data.where.box = "0033";	  
		var params = $.toJSON(data);
		  $.ajax({
			  url:'/combobox.action',
			  type:'post',
			  dataType:'json',
			  data:params,
			  contentType:'application/json',
			  success:function(data){
				if (data.success == "00") {
                    var datas = data.data.rows;
                   //�������з����㷨
					 $.each(datas, function(i, m) {
                        $("#profit_algorithm").append($("<option value='" + m.key + "'></option>").html(m.value));
                    })

                }
                else {
                    alert(data.msg);
                }
				  },
			   error: function(jqXHR, textStatus, errorThrown) {
                alert("error:" + errorThrown.message);
            }
			  });

 
 
		var data = {};
		data.fc = "0100000R";
		data.data = {};
		data.data.where = {};data.data.where.box = "0034";	  
		var params = $.toJSON(data);
		  $.ajax({
			  url:'/combobox.action',
			  type:'post',
			  dataType:'json',
			  data:params,
			  contentType:'application/json',
			  success:function(data){
				if (data.success == "00") {
                    var datas = data.data.rows;
                   //�Ʒ�����
					 $.each(datas, function(i, m) {
                        $("#billing_type").append($("<option value='" + m.key + "'></option>").html(m.value));
                    })

                }
                else {
                    alert(data.msg);
                }
				  },
			   error: function(jqXHR, textStatus, errorThrown) {
                alert("error:" + errorThrown.message);
            }
			  });

 
 
 
		var data = {};
		data.fc = "0100000R";
		data.data = {};
		data.data.where = {};data.data.where.box = "0035";	  
		var params = $.toJSON(data);
		  $.ajax({
			  url:'/combobox.action',
			  type:'post',
			  dataType:'json',
			  data:params,
			  contentType:'application/json',
			  success:function(data){
				if (data.success == "00") {
                    var datas = data.data.rows;
                   //����
					 $.each(datas, function(i, m) {
                        $("#profit_side").append($("<option value='" + m.key + "'></option>").html(m.value));
                    })

                }
                else {
                    alert(data.msg);
                }
				  },
			   error: function(jqXHR, textStatus, errorThrown) {
                alert("error:" + errorThrown.message);
            }
			  });

 
 
		var data = {};
		data.fc = "0100000R";
		data.data = {};
		data.data.where = {};data.data.where.box = "0036";	  
		var params = $.toJSON(data);
		  $.ajax({
			  url:'/combobox.action',
			  type:'post',
			  dataType:'json',
			  data:params,
			  contentType:'application/json',
			  success:function(data){
				if (data.success == "00") {
                    var datas = data.data.rows;
                   //�Ʒѷ�ʽ
					 $.each(datas, function(i, m) {
                        $("#bill_way").append($("<option value='" + m.key + "'></option>").html(m.value));
                    })

                }
                else {
                    alert(data.msg);
                }
				  },
			   error: function(jqXHR, textStatus, errorThrown) {
                alert("error:" + errorThrown.message);
            }
			  });

 
  
		var data = {};
		data.fc = "0100000R";
		data.data = {};
		data.data.where = {};
		data.data.where.box = "0037";	  
		var params = $.toJSON(data);
		  $.ajax({
			  url:'/combobox.action',
			  type:'post',
			  dataType:'json',
			  data:params,
			  contentType:'application/json',
			  success:function(data){
				if (data.success == "00") {
                    var datas = data.data.rows;
                   //��������
					 $.each(datas, function(i, m) {
                        $("#report_generation").append($("<option value='" + m.key + "'></option>").html(m.value));
                    })

                }
                else {
                    alert(data.msg);
                }
				  },
			   error: function(jqXHR, textStatus, errorThrown) {
                alert("error:" + errorThrown.message);
            }
			  });

 
  
		var data = {};
		data.fc = "0100000R";
		data.data = {};
		data.data.where = {};data.data.where.box = "0038";	  
		var params = $.toJSON(data);
		  $.ajax({
			  url:'/combobox.action',
			  type:'post',
			  dataType:'json',
			  data:params,
			  contentType:'application/json',
			  success:function(data){
				if (data.success == "00") {
                    var datas = data.data.rows;
                   //��������������
					 $.each(datas, function(i, m) {
                        $("#fee_liquidation").append($("<option value='" + m.key + "'></option>").html(m.value));
                    })

                }
                else {
                    alert(data.msg);
                }
				  },
			   error: function(jqXHR, textStatus, errorThrown) {
                alert("error:" + errorThrown.message);
            }
			  });

 
 
		var data = {};
		data.fc = "0100000R";
		data.data = {};
		data.data.where = {};data.data.where.box = "0039";	  
		var params = $.toJSON(data);
		  $.ajax({
			  url:'/combobox.action',
			  type:'post',
			  dataType:'json',
			  data:params,
			  contentType:'application/json',
			  success:function(data){
				if (data.success == "00") {
                    var datas = data.data.rows;
                   //ǿ���˳�ԭ��
					 $.each(datas, function(i, m) {
                        $("#force_quit").append($("<option value='" + m.key + "'></option>").html(m.value));
                    })

                }
                else {
                    alert(data.msg);
                }
				  },
			   error: function(jqXHR, textStatus, errorThrown) {
                alert("error:" + errorThrown.message);
            }
			  });

 
 
		var data = {};
		data.fc = "0100000R";
		data.data = {};
		data.data.where = {};data.data.where.box = "0040";	  
		var params = $.toJSON(data);
		  $.ajax({
			  url:'/combobox.action',
			  type:'post',
			  dataType:'json',
			  data:params,
			  contentType:'application/json',
			  success:function(data){
				if (data.success == "00") {
                    var datas = data.data.rows;
                   //�й�Ӧ������
					 $.each(datas, function(i, m) {
                        $("#application_type").append($("<option value='" + m.key + "'></option>").html(m.value));
                    })

                }
                else {
                    alert(data.msg);
                }
				  },
			   error: function(jqXHR, textStatus, errorThrown) {
                alert("error:" + errorThrown.message);
            }
			  });

 
 
 
		var data = {};
		data.fc = "0100000R";
		data.data = {};
		data.data.where = {};data.data.where.box = "0041";	  
		var params = $.toJSON(data);
		  $.ajax({
			  url:'/combobox.action',
			  type:'post',
			  dataType:'json',
			  data:params,
			  contentType:'application/json',
			  success:function(data){
				if (data.success == "00") {
                    var datas = data.data.rows;
                   //���ɽ����ģʽ��
					 $.each(datas, function(i, m) {
                        $("#late_fee").append($("<option value='" + m.key + "'></option>").html(m.value));
                    })

                }
                else {
                    alert(data.msg);
                }
				  },
			   error: function(jqXHR, textStatus, errorThrown) {
                alert("error:" + errorThrown.message);
            }
			  });

 
 
 
		var data = {};
		data.fc = "0100000R";
		data.data = {};
		data.data.where = {};data.data.where.box = "0042";	  
		var params = $.toJSON(data);
		  $.ajax({
			  url:'/combobox.action',
			  type:'post',
			  dataType:'json',
			  data:params,
			  contentType:'application/json',
			  success:function(data){
				if (data.success == "00") {
                    var datas = data.data.rows;
                   //���ɽ��û�����
					 $.each(datas, function(i, m) {
                        $("#late_fee_type").append($("<option value='" + m.key + "'></option>").html(m.value));
                    })

                }
                else {
                    alert(data.msg);
                }
				  },
			   error: function(jqXHR, textStatus, errorThrown) {
                alert("error:" + errorThrown.message);
            }
			  });

 
 
 
		var data = {};
		data.fc = "0100000R";
		data.data = {};
		data.data.where = {};data.data.where.box = "0043";	  
		var params = $.toJSON(data);
		  $.ajax({
			  url:'/combobox.action',
			  type:'post',
			  dataType:'json',
			  data:params,
			  contentType:'application/json',
			  success:function(data){
				if (data.success == "00") {
                    var datas = data.data.rows;
                   //˰�����
					 $.each(datas, function(i, m) {
                        $("#tax_category").append($("<option value='" + m.key + "'></option>").html(m.value));
                    })

                }
                else {
                    alert(data.msg);
                }
				  },
			   error: function(jqXHR, textStatus, errorThrown) {
                alert("error:" + errorThrown.message);
            }
			  });

 
 
		var data = {};
		data.fc = "0100000R";
		data.data = {};
		data.data.where = {};data.data.where.box = "0044";	  
		var params = $.toJSON(data);
		  $.ajax({
			  url:'/combobox.action',
			  type:'post',
			  dataType:'json',
			  data:params,
			  contentType:'application/json',
			  success:function(data){
				if (data.success == "00") {
                    var datas = data.data.rows;
                   //�����������
					 $.each(datas, function(i, m) {
                        $("#password_encryption").append($("<option value='" + m.key + "'></option>").html(m.value));
                    })

                }
                else {
                    alert(data.msg);
                }
				  },
			   error: function(jqXHR, textStatus, errorThrown) {
                alert("error:" + errorThrown.message);
            }
			  });

 
 
		var data = {};
		data.fc = "0100000R";
		data.data = {};
		data.data.where = {};data.data.where.box = "0045";	  
		var params = $.toJSON(data);
		  $.ajax({
			  url:'/combobox.action',
			  type:'post',
			  dataType:'json',
			  data:params,
			  contentType:'application/json',
			  success:function(data){
				if (data.success == "00") {
                    var datas = data.data.rows;
                   //�Ƶ��Ǽ�
					 $.each(datas, function(i, m) {
                        $("#hotels").append($("<option value='" + m.key + "'></option>").html(m.value));
                    })

                }
                else {
                    alert(data.msg);
                }
				  },
			   error: function(jqXHR, textStatus, errorThrown) {
                alert("error:" + errorThrown.message);
            }
			  });

 
 
 
		var data = {};
		data.fc = "0100000R";
		data.data = {};
		data.data.where = {};data.data.where.box = "0046";	  
		var params = $.toJSON(data);
		  $.ajax({
			  url:'/combobox.action',
			  type:'post',
			  dataType:'json',
			  data:params,
			  contentType:'application/json',
			  success:function(data){
				if (data.success == "00") {
                    var datas = data.data.rows;
                   //Ѻ�����
					 $.each(datas, function(i, m) {
                        $("#deposit_currency").append($("<option value='" + m.key + "'></option>").html(m.value));
                    })

                }
                else {
                    alert(data.msg);
                }
				  },
			   error: function(jqXHR, textStatus, errorThrown) {
                alert("error:" + errorThrown.message);
            }
			  });

 
 
 
		var data = {};
		data.fc = "0100000R";
		data.data = {};
		data.data.where = {};
		data.data.where.box = "0047";	  
		var params = $.toJSON(data);
		  $.ajax({
			  url:'/combobox.action',
			  type:'post',
			  dataType:'json',
			  data:params,
			  contentType:'application/json',
			  success:function(data){
				if (data.success == "00") {
                    var datas = data.data.rows;
                   //����ѱ���
					 $.each(datas, function(i, m) {
                        $("#service_charge").append($("<option value='" + m.key + "'></option>").html(m.value));
                    })

                }
                else {
                    alert(data.msg);
                }
				  },
			   error: function(jqXHR, textStatus, errorThrown) {
                alert("error:" + errorThrown.message);
            }
			  });

 
 
 
		var data = {};
		data.fc = "0100000R";
		data.data = {};
		data.data.where = {};data.data.where.box = "0048";	  
		var params = $.toJSON(data);
		  $.ajax({
			  url:'/combobox.action',
			  type:'post',
			  dataType:'json',
			  data:params,
			  contentType:'application/json',
			  success:function(data){
				if (data.success == "00") {
                    var datas = data.data.rows;
                   //�������ȡ����
					 $.each(datas, function(i, m) {
                        $("#charge_cycle").append($("<option value='" + m.key + "'></option>").html(m.value));
                    })

                }
                else {
                    alert(data.msg);
                }
				  },
			   error: function(jqXHR, textStatus, errorThrown) {
                alert("error:" + errorThrown.message);
            }
			  });

 
 
		var data = {};
		data.fc = "0100000R";
		data.data = {};
		data.data.where = {};data.data.where.box = "0049";	  
		var params = $.toJSON(data);
		  $.ajax({
			  url:'/combobox.action',
			  type:'post',
			  dataType:'json',
			  data:params,
			  contentType:'application/json',
			  success:function(data){
				if (data.success == "00") {
                    var datas = data.data.rows;
                   //�̻���������
					 $.each(datas, function(i, m) {
                        $("#merchant_transactions").append($("<option value='" + m.key + "'></option>").html(m.value));
                    })

                }
                else {
                    alert(data.msg);
                }
				  },
			   error: function(jqXHR, textStatus, errorThrown) {
                alert("error:" + errorThrown.message);
            }
			  });

 
 
 
		var data = {};
		data.fc = "0100000R";
		data.data = {};
		data.data.where = {};data.data.where.box = "0050";	  
		var params = $.toJSON(data);
		  $.ajax({
			  url:'/combobox.action',
			  type:'post',
			  dataType:'json',
			  data:params,
			  contentType:'application/json',
			  success:function(data){
				if (data.success == "00") {
                    var datas = data.data.rows;
                   //�̻���������
					 $.each(datas, function(i, m) {
                        $("#merchant_channels").append($("<option value='" + m.key + "'></option>").html(m.value));
                    })

                }
                else {
                    alert(data.msg);
                }
				  },
			   error: function(jqXHR, textStatus, errorThrown) {
                alert("error:" + errorThrown.message);
            }
			  });

 
 
		var data = {};
		data.fc = "0100000R";
		data.data = {};
		data.data.where = {};data.data.where.box = "0051";	  
		var params = $.toJSON(data);
		  $.ajax({
			  url:'/combobox.action',
			  type:'post',
			  dataType:'json',
			  data:params,
			  contentType:'application/json',
			  success:function(data){
				if (data.success == "00") {
                    var datas = data.data.rows;
                   //�������־
					 $.each(datas, function(i, m) {
                        $("#chains_flag").append($("<option value='" + m.key + "'></option>").html(m.value));
                    })

                }
                else {
                    alert(data.msg);
                }
				  },
			   error: function(jqXHR, textStatus, errorThrown) {
                alert("error:" + errorThrown.message);
            }
			  });

 
 
		var data = {};
		data.fc = "0100000R";
		data.data = {};
		data.data.where = {};data.data.where.box = "0052";	  
		var params = $.toJSON(data);
		  $.ajax({
			  url:'/combobox.action',
			  type:'post',
			  dataType:'json',
			  data:params,
			  contentType:'application/json',
			  success:function(data){
				if (data.success == "00") {
                    var datas = data.data.rows;
                   //�ֵܷ��ʶ
					 $.each(datas, function(i, m) {
                        $("#total_branch_logo").append($("<option value='" + m.key + "'></option>").html(m.value));
                    })

                }
                else {
                    alert(data.msg);
                }
				  },
			   error: function(jqXHR, textStatus, errorThrown) {
                alert("error:" + errorThrown.message);
            }
			  });

 
 
		var data = {};
		data.fc = "0100000R";
		data.data = {};
		data.data.where = {};data.data.where.box = "0053";	  
		var params = $.toJSON(data);
		  $.ajax({
			  url:'/combobox.action',
			  type:'post',
			  dataType:'json',
			  data:params,
			  contentType:'application/json',
			  success:function(data){
				if (data.success == "00") {
                    var datas = data.data.rows;
                   //�����̻���������
					 $.each(datas, function(i, m) {
                        $("#network_type").append($("<option value='" + m.key + "'></option>").html(m.value));
                    })

                }
                else {
                    alert(data.msg);
                }
				  },
			   error: function(jqXHR, textStatus, errorThrown) {
                alert("error:" + errorThrown.message);
            }
			  });
